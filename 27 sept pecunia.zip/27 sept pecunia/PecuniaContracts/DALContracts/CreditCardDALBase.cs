﻿using Pecunia.Entities;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Pecunia.Contracts.DALContracts
{
    /// <summary>
    /// This abstract class acts as a base class for CreditCardDAL class
    /// </summary>
    public abstract class CreditCardDALBase
    {
        protected static List<CreditCard> creditCardsList = new List<CreditCard>();

        private static string fileName = "creditCards.json";

        //Methods for CRUD operations
        public abstract bool AddCreditCardDAL(CreditCard creditCard);
        public abstract List<CreditCard> GetCreditCardListDAL();
        public abstract bool UpdateCreditCardStatusDAL(string creditCardNumber, string cardStatus);
        public abstract List<CreditCard> GetCreditCardsByCustomerIdDAL(Guid CustomerId);
        public abstract CreditCard GetCreditCardByCreditCardNumberDAL(string cardNumber);

        /// <summary>
        /// Writes collection to the file in JSON format.
        /// </summary>
        public void Serialize()
        {
            string serializedJson = JsonConvert.SerializeObject(creditCardsList);
            using (StreamWriter streamWriter = new StreamWriter(fileName))
            {
                streamWriter.Write(serializedJson);
                streamWriter.Close();
            }
        }
        /// <summary>
        /// Reads collection from the file in JSON format.
        /// </summary>
        public void Deserialize()
        {
            string fileContent = string.Empty;
            if (!File.Exists(fileName))
                File.Create(fileName).Close();

            using (StreamReader streamReader = new StreamReader(fileName))
            {
                fileContent = streamReader.ReadToEnd();
                streamReader.Close();
                var creditCardsListFromFile = JsonConvert.DeserializeObject<List<CreditCard>>(fileContent);
                if (creditCardsListFromFile != null)
                {
                    creditCardsList = creditCardsListFromFile;
                }
            }
        }


        /// <summary>
        /// Static Constructor.
        /// </summary>
        public CreditCardDALBase()
        {
            Deserialize();


        }




    }
}
