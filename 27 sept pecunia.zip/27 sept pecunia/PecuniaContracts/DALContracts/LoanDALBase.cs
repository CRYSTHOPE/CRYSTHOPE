﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pecunia.Entities;
using Newtonsoft.Json;



namespace Pecunia.Contracts.DALContracts
{/// <summary>
/// Abstract class for Loan DAL class
/// </summary>
    public abstract class CarLoanDALBase
    {
        //List of all Loan
        protected static List<CarLoan> CarLoanList = new List<CarLoan>();
        private static string CarFileName = "CarLoan.json";

        //Methods for CRUD operations
        public abstract bool AddLoanDAL(CarLoan NewCarloan);
        public abstract List<CarLoan> GetAllCarLoanDAL();
        public abstract CarLoan GetCarLoanByLoanIDDAL(Guid loanID);
        public abstract List<CarLoan> GetCarLoanByTypeDAL(string LoanType);
        public abstract List<CarLoan> GetCarLoanByLoanStatusDAL(string LoanStatus);
        public abstract bool UpdateCarLoanDAL(CarLoan updatedloan);
        public abstract bool DeleteCarLoanDAL(Guid deleteLoanID);

        public void CarSerialize()
        {
            string serializedJson = JsonConvert.SerializeObject(CarLoanList);
            using (StreamWriter streamWriter = new StreamWriter(CarFileName))
            {
                streamWriter.Write(serializedJson);
                streamWriter.Close();
            }
        }
        /// <summary>
        /// Reads collection from the file in JSON format.
        /// </summary>
        public static void Deserialize()
        {
            string fileContent = string.Empty;
            if (!File.Exists(CarFileName))
                File.Create(CarFileName).Close();

            using (StreamReader streamReader = new StreamReader(CarFileName))
            {
                fileContent = streamReader.ReadToEnd();
                streamReader.Close();
                var CarListFromFile = JsonConvert.DeserializeObject<List<CarLoan>>(fileContent);
                if (CarListFromFile != null)
                {
                    CarLoanList = CarListFromFile;
                }
            }
        }


        public CarLoanDALBase()
        {
            Deserialize();
        }
    }



    /// <summary>
    /// Abstract class for Loan DAL class
    /// </summary>
    public abstract class HomeLoanDALBase
    {
        //List of all Loan
        protected static List<HomeLoan> HomeLoanList = new List<HomeLoan>();
        private static string HomeFileName = "HomeLoan.json";

        //Methods for CRUD operations
        public abstract bool AddLoanDAL(HomeLoan NewHomeloan);
        public abstract List<HomeLoan> GetAllHomeLoanDAL();
        public abstract HomeLoan GetHomeLoanByLoanIDDAL(Guid loanID);
        public abstract List<HomeLoan> GetHomeLoanByTypeDAL(string LoanType);
        public abstract List<HomeLoan> GetHomeLoanByLoanStatusDAL(string LoanStatus);
        public abstract bool UpdateHomeLoanDAL(HomeLoan updatedloan);
        public abstract bool DeleteHomeLoanDAL(Guid deleteLoanID);

        /// <summary>
        /// To serialize and store all data in loan.json file
        /// </summary>
        public void Homeserialize()
        {
            string serializedJson = JsonConvert.SerializeObject(HomeLoanList);
            using (StreamWriter streamWriter = new StreamWriter(HomeFileName))
            {
                streamWriter.Write(serializedJson);
                streamWriter.Close();
            }
        }
        /// <summary>
        /// To deserialize the loan.Json file and store into list
        /// </summary>
        public static void Deserialize()
        {
            string fileContent = string.Empty;
            if (!File.Exists(HomeFileName))
                File.Create(HomeFileName).Close();

            using (StreamReader streamReader = new StreamReader(HomeFileName))
            {
                fileContent = streamReader.ReadToEnd();
                streamReader.Close();
                var HomeListFromFile = JsonConvert.DeserializeObject<List<HomeLoan>>(fileContent);
                if (HomeListFromFile != null)
                {
                    HomeLoanList = HomeListFromFile;
                }
            }
        }
        public HomeLoanDALBase()
        {
            Deserialize();
        }
    }


    /// <summary>
    /// Abstract class for Loan DAL class
    /// </summary>
    public abstract class EducationLoanDALBase
    {
        //List of all Loan
        protected static List<EducationLoan> EducationLoanList = new List<EducationLoan>();
        private static string EducationFileName = "EducationLoan.json";

        //Methods for CRUD operations
        public abstract bool AddLoanDAL(EducationLoan NewEducationloan);
        public abstract List<EducationLoan> GetAllEducationLoanDAL();
        public abstract EducationLoan GetEducationLoanByLoanIDDAL(Guid loanID);
        public abstract List<EducationLoan> GetEducationLoanByTypeDAL(string LoanType);
        public abstract List<EducationLoan> GetEducationLoanByLoanStatusDAL(string LoanStatus);
        public abstract bool UpdateEducationLoanDAL(EducationLoan updatedloan);
        public abstract bool DeleteEducationLoanDAL(Guid deleteLoanID);

        /// <summary>
        /// To serialize and store all data in loan.json file
        /// </summary>
        public void Educationserialize()
        {
            string serializedJson = JsonConvert.SerializeObject(EducationLoanList);
            using (StreamWriter streamWriter = new StreamWriter(EducationFileName))
            {
                streamWriter.Write(serializedJson);
                streamWriter.Close();
            }
        }
        /// <summary>
        /// To deserialize the loan.Json file and store into list
        /// </summary>
        public static void Deserialize()
        {
            string fileContent = string.Empty;
            if (!File.Exists(EducationFileName))
                File.Create(EducationFileName).Close();

            using (StreamReader streamReader = new StreamReader(EducationFileName))
            {
                fileContent = streamReader.ReadToEnd();
                streamReader.Close();
                var EduListFromFile = JsonConvert.DeserializeObject<List<EducationLoan>>(fileContent);
                if (EduListFromFile != null)
                {
                    EducationLoanList = EduListFromFile;
                }
            }
        }

        public EducationLoanDALBase()
        {
            Deserialize();
        }

    }


    /// <summary>
    /// Abstract class for Loan DAL class
    /// </summary>
    public abstract class PersonalLoanDALBase
    {
        //List of all Loan
        protected static List<PersonalLoan> PersonalLoanList = new List<PersonalLoan>();
        private static string PersonalFileName = "PersonalLoan.json";

        //Methods for CRUD operations
        public abstract bool AddLoanDAL(PersonalLoan NewCarloan);
        public abstract List<PersonalLoan> GetAllPersonalLoanDAL();
        public abstract PersonalLoan GetPersonalLoanByLoanIDDAL(Guid loanID);
        public abstract List<PersonalLoan> GetPersonalLoanByTypeDAL(string LoanType);
        public abstract List<PersonalLoan> GetPersonalLoanByLoanStatusDAL(string LoanStatus);
        public abstract bool UpdatePersonalLoanDAL(PersonalLoan updatedloan);
        public abstract bool DeletePersonalLoanDAL(Guid deleteLoanID);

        /// <summary>
        /// To serialize and store all data in loan.json file
        /// </summary>
        public bool Personalserialize()
        {
            bool serialized = false;
            string serializedJson = JsonConvert.SerializeObject(PersonalLoanList);
            using (StreamWriter streamWriter = new StreamWriter(PersonalFileName))
            {
                streamWriter.Write(serializedJson);
                streamWriter.Close();
                serialized = true;
            }
            return serialized;
        }
        /// <summary>
        /// To deserialize the loan.Json file and store into list
        /// </summary>
        public static void Deserialize()
        {
            string fileContent = string.Empty;
            if (!File.Exists(PersonalFileName))
                File.Create(PersonalFileName).Close();

            using (StreamReader streamReader = new StreamReader(PersonalFileName))
            {
                fileContent = streamReader.ReadToEnd();
                streamReader.Close();
                var PerListFromFile = JsonConvert.DeserializeObject<List<PersonalLoan>>(fileContent);
                if (PerListFromFile != null)
                {
                    PersonalLoanList = PerListFromFile;
                }
            }
        }
        public PersonalLoanDALBase()
        {
            Deserialize();
        }


    }
}
