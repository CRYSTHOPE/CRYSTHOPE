﻿using Pecunia.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pecunia.Contracts.BLContracts
{
    
        public interface IRegularAccountBL : IDisposable
        {
            Task<bool> CreateAccountBL(RegularAccount newAccount);
            Task<List<RegularAccount>> GetAllAccountsBL();
            Task<RegularAccount> GetAccountByAccountNoBL(string searchAccountNo);
            Task<List<RegularAccount>> GetAccountsByCustomerNoBL(string searchCustomerNo);
            Task<List<RegularAccount>> GetAccountsByTypeBL(string searchAccountType);
            Task<List<RegularAccount>> GetAccountsByBranchBL(string searchBranch);
            Task<List<RegularAccount>> GetAccountsByAccountOpeningDateBL(DateTime d1, DateTime d2);
            Task<double> GetBalanceBL(string accountNumber);
            Task<bool> UpdateBalanceBL(string accountNumber, double balance);
            Task<bool> UpdateBranchBL(string accountNumber, string branch);
            Task<bool> UpdateAccountTypeBL(string accountNumber, string accountType);
            Task<bool> DeleteAccountBL(string deleteAccountNo);
        }
}
