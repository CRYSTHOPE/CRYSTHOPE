﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pecunia.Helpers
{
    /// <summary>
    /// Assigning starting and default value to accounts
    /// </summary>
    public class CardConfiguration
    {
        public static double baseDebitCardNumber = 100000000000;
        public static double baseCreditCardNumber = 100000000000;

    }
}
