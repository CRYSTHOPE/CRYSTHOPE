﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pecunia.Entities;
using Pecunia.Contracts.BLContracts;
using Pecunia.DataAcessLayer;
using Pecunia.Contracts.DALContracts;

namespace Pecunia.BusinessLayer
{
    public class CarLoanBL : BLBase<CarLoan>, ICarLoanBL, IDisposable
    {
        //fields
        CarLoanDALBase carloanDAL;

        /// <summary>
        /// Constructor.
        /// </summary>
        public CarLoanBL()
        {
            this.carloanDAL = new CarLoanDAL();
        }
        /// <summary>
        /// Adds new supplier to Suppliers collection.
        /// </summary>
        /// <param name="newCarLoan">Contains the supplier details to be added.</param>
        /// <returns>Determinates whether the new supplier is added.</returns>
        public async Task<bool> AddCarLoanBL(CarLoan newCarLoan , string Customernumber)
        {
            bool LoanAdded = false;
            try
            {
                CustomerBL cbl = new CustomerBL();
                Customer cust = await  cbl.GetCustomerByCustomerNumberBL(Customernumber);
                newCarLoan.YearlyIncome = cust.AnnualIncome;
                newCarLoan.YearsOfService = cust.WorkExperience;
                if (await Validate(newCarLoan))
                {
                    await Task.Run(() =>
                    {

                        LoanAdded = carloanDAL.AddLoanDAL(newCarLoan);

                    });
                }
            }
            catch (Exception)
            {
                throw;
            }
            return LoanAdded;
        }


        /// <summary>
        /// Gets all suppliers from the collection.
        /// </summary>
        /// <returns>Returns list of all suppliers.</returns>
        public async Task<List<CarLoan>> GetAllCarLoanBL()
        {
            List<CarLoan> CarsList = null;
            try
            {
                await Task.Run(() =>
                {
                    CarsList = carloanDAL.GetAllCarLoanDAL();
                });
            }
            catch (Exception)
            {
                throw;
            }
            return CarsList;
        }

        public async Task<CarLoan> GetCarLoanByLoanIDBL(Guid loanID)
        {
            CarLoan carloan = null;
            try
            {
                await Task.Run(() =>
                {
                    carloan = carloanDAL.GetCarLoanByLoanIDDAL(loanID);
                });
            }
            catch (Exception)
            {
                throw;
            }
            return carloan;
        }

        public async Task<List<CarLoan>> GetCarLoanByLoanStatusBL(string LoanStatus)
        {
            List<CarLoan> carloan = null;
            try
            {
                await Task.Run(() =>
                {
                    carloan = carloanDAL.GetCarLoanByLoanStatusDAL(LoanStatus);
                });
            }
            catch (Exception)
            {
                throw;
            }
            return carloan;
        }

        public async Task<bool> UpdateCarLoanBL(CarLoan updatedloan)
        {
            bool Updated = false;
            try
            {
                if ((await Validate(updatedloan)) && (await GetCarLoanByLoanIDBL(updatedloan.LoanID)) != null)
                {

                    Updated = carloanDAL.UpdateCarLoanDAL(updatedloan);

                }
            }
            catch (Exception)
            {
                throw;
            }
            return Updated;
        }


        public async Task<bool> DeleteCarLoanBL(Guid deleteLoanID)
        {
            {
                bool loandeleted = false;
                try
                {
                    await Task.Run(() =>
                    {
                        loandeleted = carloanDAL.DeleteCarLoanDAL(deleteLoanID);
                    });
                }
                catch (Exception)
                {
                    throw;
                }
                return loandeleted;
            }
        }
        public async Task<bool> CarSerialize()
        {
            bool serialized = false;
            try
            {
                await Task.Run(() =>
                {
                    carloanDAL.CarSerialize();
                    serialized = true;
                });
            }
            catch (Exception)
            {
                throw;
            }
            return serialized;
        }
        public void Dispose()
        {
            ((CarLoanDAL)carloanDAL).Dispose();
        }
    }
    public class HomeLoanBL : BLBase<HomeLoan>, IHomeLoanBL, IDisposable
    {
        //fields
        HomeLoanDALBase homeloanDAL;

        /// <summary>
        /// Constructor.
        /// </summary>
        public HomeLoanBL()
        {
            this.homeloanDAL = new HomeLoanDAL();
        }
        /// <summary>
        /// Adds new supplier to Suppliers collection.
        /// </summary>
        /// <param name="newCarLoan">Contains the supplier details to be added.</param>
        /// <returns>Determinates whether the new supplier is added.</returns>
        public async Task<bool> AddHomeLoanBL(HomeLoan newHomeLoan)
        {
            bool LoanAdded = false;
            try
            {
                if (await Validate(newHomeLoan))
                {
                    await Task.Run(() =>
                    {

                        LoanAdded = homeloanDAL.AddLoanDAL(newHomeLoan);

                    });
                }
            }
            catch (Exception)
            {
                throw;
            }
            return LoanAdded;
        }


        /// <summary>
        /// Gets all suppliers from the collection.
        /// </summary>
        /// <returns>Returns list of all suppliers.</returns>
        public async Task<List<HomeLoan>> GetAllHomeLoanBL()
        {
            List<HomeLoan> HomeList = null;
            try
            {
                await Task.Run(() =>
                {
                    HomeList = homeloanDAL.GetAllHomeLoanDAL();
                });
            }
            catch (Exception)
            {
                throw;
            }
            return HomeList;
        }

        public async Task<HomeLoan> GetHomeLoanByLoanIDBL(Guid loanID)
        {
            HomeLoan homeloan = null;
            try
            {
                await Task.Run(() =>
                {
                    homeloan = homeloanDAL.GetHomeLoanByLoanIDDAL(loanID);
                });
            }
            catch (Exception)
            {
                throw;
            }
            return homeloan;
        }

        public async Task<List<HomeLoan>> GetHomeLoanByLoanStatusBL(string LoanStatus)
        {
            List<HomeLoan> Homeloan = null;
            try
            {
                await Task.Run(() =>
                {
                    Homeloan = homeloanDAL.GetHomeLoanByLoanStatusDAL(LoanStatus);
                });
            }
            catch (Exception)
            {
                throw;
            }
            return Homeloan;
        }

        public async Task<bool> UpdateHomeLoanBL(HomeLoan updatedloan)
        {
            bool Updated = false;
            try
            {
                if ((await Validate(updatedloan)) && (await GetHomeLoanByLoanIDBL(updatedloan.LoanID)) != null)
                {

                    Updated = homeloanDAL.UpdateHomeLoanDAL(updatedloan);

                }
            }
            catch (Exception)
            {
                throw;
            }
            return Updated;
        }


        public async Task<bool> DeleteHomeLoanBL(Guid deleteLoanID)
        {
            {
                bool loandeleted = false;
                try
                {
                    await Task.Run(() =>
                    {
                        loandeleted = homeloanDAL.DeleteHomeLoanDAL(deleteLoanID);
                    });
                }
                catch (Exception)
                {
                    throw;
                }
                return loandeleted;
            }
        }
        public async Task<bool> HomeSerialize()
        {
            bool serialized = false;
            try
            {
                await Task.Run(() =>
                {
                    homeloanDAL.Homeserialize();
                    serialized = true;
                });
            }
            catch (Exception)
            {
                throw;
            }
            return serialized;
        }
        public void Dispose()
        {
            ((HomeLoanDAL)homeloanDAL).Dispose();
        }
    }
    public class PersonalLoanBL : BLBase<PersonalLoan>, IPersonalLoanBL, IDisposable
    {
        //fields
        PersonalLoanDALBase personalloanDAL;

        /// <summary>
        /// Constructor.
        /// </summary>
        public PersonalLoanBL()
        {
            this.personalloanDAL = new PersonalLoanDAL();
        }
        /// <summary>
        /// Adds new supplier to Suppliers collection.
        /// </summary>
        /// <param name="newCarLoan">Contains the supplier details to be added.</param>
        /// <returns>Determinates whether the new supplier is added.</returns>
        public async Task<bool> AddPersonalLoanBL(PersonalLoan newPersonalLoan)
        {
            bool LoanAdded = false;
            try
            {
                if (await Validate(newPersonalLoan))
                {
                    await Task.Run(() =>
                    {

                        LoanAdded = personalloanDAL.AddLoanDAL(newPersonalLoan);

                    });
                }
            }
            catch (Exception)
            {
                throw;
            }
            return LoanAdded;
        }


        /// <summary>
        /// Gets all suppliers from the collection.
        /// </summary>
        /// <returns>Returns list of all suppliers.</returns>
        public async Task<List<PersonalLoan>> GetAllPersonalLoanBL()
        {
            List<PersonalLoan> personalList = null;
            try
            {
                await Task.Run(() =>
                {
                    personalList = personalloanDAL.GetAllPersonalLoanDAL();
                });
            }
            catch (Exception)
            {
                throw;
            }
            return personalList;
        }

        public async Task<PersonalLoan> GetPersonalLoanByLoanIDBL(Guid loanID)
        {
            PersonalLoan personalloan = null;
            try
            {
                await Task.Run(() =>
                {
                    personalloan = personalloanDAL.GetPersonalLoanByLoanIDDAL(loanID);
                });
            }
            catch (Exception)
            {
                throw;
            }
            return personalloan;
        }

        public async Task<List<PersonalLoan>> GetPersonalLoanByLoanStatusBL(string LoanStatus)
        {
            List<PersonalLoan> personalloan = null;
            try
            {
                await Task.Run(() =>
                {
                    personalloan = personalloanDAL.GetPersonalLoanByLoanStatusDAL(LoanStatus);
                });
            }
            catch (Exception)
            {
                throw;
            }
            return personalloan;
        }

        public async Task<bool> UpdatePersonalLoanBL(PersonalLoan updatedloan)
        {
            bool Updated = false;
            try
            {
                if ((await Validate(updatedloan)) && (await GetPersonalLoanByLoanIDBL(updatedloan.LoanID)) != null)
                {

                    Updated = personalloanDAL.UpdatePersonalLoanDAL(updatedloan);

                }
            }
            catch (Exception)
            {
                throw;
            }
            return Updated;
        }


        public async Task<bool> DeleteLoanBL(Guid deleteLoanID)
        {
            {
                bool loandeleted = false;
                try
                {
                    await Task.Run(() =>
                    {
                        loandeleted = personalloanDAL.DeletePersonalLoanDAL(deleteLoanID);
                    });
                }
                catch (Exception)
                {
                    throw;
                }
                return loandeleted;
            }
        }
        public async Task<bool> PersonalSerialize()
        {
            bool serialized = false;
            try
            {
                await Task.Run(() =>
                {
                    personalloanDAL.Personalserialize();
                    serialized = true;
                });
            }
            catch (Exception)
            {
                throw;
            }
            return serialized;
        }
        public void Dispose()
        {
            ((PersonalLoanDAL)personalloanDAL).Dispose();
        }
    }
    public class EducationLoanBL : BLBase<EducationLoan>, IEducationLoanBL, IDisposable
    {
        //fields
        EducationLoanDALBase educationloanDAL;

        /// <summary>
        /// Constructor.
        /// </summary>
        public EducationLoanBL()
        {
            this.educationloanDAL = new EducationLoanDAL();
        }
        /// <summary>
        /// Adds new supplier to Suppliers collection.
        /// </summary>
        /// <param name="newCarLoan">Contains the supplier details to be added.</param>
        /// <returns>Determinates whether the new supplier is added.</returns>
        public async Task<bool> AddEducationLoanBL(EducationLoan neweducationLoan)
        {
            bool LoanAdded = false;
            try
            {
                if (await Validate(neweducationLoan))
                {
                    await Task.Run(() =>
                    {

                        LoanAdded = educationloanDAL.AddLoanDAL(neweducationLoan);

                    });
                }
            }
            catch (Exception)
            {
                throw;
            }
            return LoanAdded;
        }


        /// <summary>
        /// Gets all suppliers from the collection.
        /// </summary>
        /// <returns>Returns list of all suppliers.</returns>
        public async Task<List<EducationLoan>> GetAllEducationLoanBL()
        {
            List<EducationLoan> educationList = null;
            try
            {
                await Task.Run(() =>
                {
                    educationList = educationloanDAL.GetAllEducationLoanDAL();
                });
            }
            catch (Exception)
            {
                throw;
            }
            return educationList;
        }

        public async Task<EducationLoan> GetEducationLoanByLoanIDBL(Guid loanID)
        {
            EducationLoan educationloan = null;
            try
            {
                await Task.Run(() =>
                {
                    educationloan = educationloanDAL.GetEducationLoanByLoanIDDAL(loanID);
                });
            }
            catch (Exception)
            {
                throw;
            }
            return educationloan;
        }

        public async Task<List<EducationLoan>> GetEducationLoanByLoanStatusBL(string LoanStatus)
        {
            List<EducationLoan> educationloan = null;
            try
            {
                await Task.Run(() =>
                {
                    educationloan = educationloanDAL.GetEducationLoanByLoanStatusDAL(LoanStatus);
                });
            }
            catch (Exception)
            {
                throw;
            }
            return educationloan;
        }

        public async Task<bool> UpdateEducationLoanBL(EducationLoan updatedloan)
        {
            bool Updated = false;
            try
            {
                if ((await Validate(updatedloan)) && (await GetEducationLoanByLoanIDBL(updatedloan.LoanID)) != null)
                {

                    Updated = educationloanDAL.UpdateEducationLoanDAL(updatedloan);

                }
            }
            catch (Exception)
            {
                throw;
            }
            return Updated;
        }


        public async Task<bool> DeleteEducationLoanBL(Guid deleteLoanID)
        {
            {
                bool loandeleted = false;
                try
                {
                    await Task.Run(() =>
                    {
                        loandeleted = educationloanDAL.DeleteEducationLoanDAL(deleteLoanID);
                    });
                }
                catch (Exception)
                {
                    throw;
                }
                return loandeleted;
            }
        }
        public async Task<bool> EducationSerialize()
        {
            bool serialized = false;
            try
            {
                await Task.Run(() =>
                {
                    educationloanDAL.Educationserialize();
                    serialized = true;
                });
            }
            catch (Exception)
            {
                throw;
            }
            return serialized;
        }

        public void Dispose()
        {
            ((EducationLoanDAL)educationloanDAL).Dispose();
        }
    }

}
