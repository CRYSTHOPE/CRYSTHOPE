﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pecunia.Entities;
using Pecunia.Contracts.BLContracts;
using Pecunia.DataAcessLayer;
using Pecunia.Exceptions;
using Pecunia.Contracts.DALContracts;
using Pecunia.Helpers;
using static System.Console;

namespace Pecunia.BusinessLayer
{
    /// <summary>
    /// Contains data access layer methods for inserting, updating, searching customers from customer collection.
    /// </summary>
    public class CustomerBL : BLBase<Customer>, ICustomerBL, IDisposable
    {
        //fields
        CustomerDAL customerDAL;

        /// <summary>
        /// Constructor.
        /// </summary>
        public CustomerBL()
        {
            this.customerDAL = new CustomerDAL();
        }

        /// <summary>
        /// Validations on data before adding or updating.
        /// </summary>
        /// <param name="entityObject">Represents object to be validated.</param>
        /// <returns>Returns a boolean value, that indicates whether the data is valid or not.</returns>
        protected async override Task<bool> Validate(Customer entityObject)
        {
            //Create string builder
            StringBuilder sb = new StringBuilder();
            bool valid = await base.Validate(entityObject);

            //Email is Unique
            var existingObject = await GetCustomerByEmailBL(entityObject.Email);
            if (existingObject != null && existingObject?.CustomerID != entityObject.CustomerID)
            {
                valid = false;
                sb.Append(Environment.NewLine + $"Email {entityObject.Email} already exists");
            }

            //Phone Number is Unique
            var existingObjectBasedOnMobile = await GetCustomerByCustomerMobileBL(entityObject.CustomerMobile);
            if (existingObjectBasedOnMobile != null && existingObjectBasedOnMobile?.CustomerID != entityObject.CustomerID)
            {
                valid = false;
                sb.Append(Environment.NewLine + $"Mobile Number {entityObject.CustomerMobile} already exists");
            }

            //PAN Number is Unique
            var existingObject2 = await GetCustomerByCustomerPANNumberBL(entityObject.CustomerPANNumber);
            if (existingObject2 != null && existingObject2?.CustomerID != entityObject.CustomerID)
            {
                valid = false;
                sb.Append(Environment.NewLine + $"PAN Number {entityObject.CustomerPANNumber} already exists");
            }
            //Aadhar Number is Unique
            var existingObject3 = await GetCustomerByCustomerAadharNumberBL(entityObject.CustomerAadharNumber);
            if (existingObject3 != null && existingObject3?.CustomerID != entityObject.CustomerID)
            {
                valid = false;
                sb.Append(Environment.NewLine + $"Aadhar Number {entityObject.CustomerAadharNumber} already exists");
            }
            // DOB validation
            if (entityObject.CustomerDOB > (DateTime.Now.AddYears(-18)))
            {
                valid = false;
                sb.Append(Environment.NewLine + "Customer DOB invalid OR Customer is below 18 years");
            }



            if (valid == false)
                throw new PecuniaException(sb.ToString());
            return valid;
        }

        /// <summary>
        /// Adds new Customer to Customers collection.
        /// </summary>
        /// <param name="newCustomer">Contains the Customer details to be added.</param>
        /// <returns>Determines whether the new Customer is added.</returns>
        public async Task<bool> AddCustomerBL(Customer newCustomer)
        {
            bool CustomerAdded = false;
            try
            {
                if (await Validate(newCustomer))
                
                {
                    //if (customerDAL.GetAllCustomersDAL().Count == 0)
                    //{
                    //    newCustomer.CustomerNumber = Convert.ToString(CustomerConfiguration.baseCustomerNumber + 1);
                    //}
                    //else
                    //{
                    //    string nextCardNo = (customerDAL.GetAllCustomersDAL().Select(temp => Convert.ToInt64(temp.CustomerNumber)).Max() + 1).ToString();


                    //}
                    customerDAL.AddCustomerDAL(newCustomer);


                    CustomerAdded = true;

                    

                }
            }
            catch (Exception)
            {
                throw;
            }
            return CustomerAdded;
        }
        public async Task<bool> serialize()
        {
            bool serialized = false;
            try
            {
                await Task.Run(() =>
                {
                    Serialize();
                    serialized = true;
                });
            }
            catch (Exception)
            {
                throw;
            }
            return serialized;
        }

        /// <summary>
        /// Gets all Customers from the collection.
        /// </summary>
        /// <returns>Returns list of all Customers.</returns>
        public async Task<List<Customer>> GetAllCustomersBL()
        {
            List<Customer> CustomersList = null;
            try
            {
                await Task.Run(() =>
                {
                    CustomersList = customerDAL.GetAllCustomersDAL();
                });
            }
            catch (Exception)
            {
                throw;
            }
            return CustomersList;
        }

        /// <summary>
        /// Gets Customer based on CustomerNumber.
        /// </summary>
        /// <param name="searchCustomerNumber">Represents CustomerNumber to search.</param>
        /// <returns>Returns Customer object.</returns>
        public async Task<Customer> GetCustomerByCustomerNumberBL(string searchCustomerNumber)
        {
            Customer matchingCustomer = null;
            try
            {
                await Task.Run(() =>
                {
                    matchingCustomer = customerDAL.GetCustomerByCustomerNumberDAL(searchCustomerNumber);
                });
            }
            catch (Exception)
            {
                throw;
            }
            return matchingCustomer;
        }

        /// <summary>
        /// Gets Customer based on CustomerName.
        /// </summary>
        /// <param name="CustomerName">Represents CustomerName to search.</param>
        /// <returns>Returns Customer object.</returns>
        public async Task<List<Customer>> GetCustomersByNameBL(string CustomerName)
        {
            List<Customer> matchingCustomers = new List<Customer>();
            try
            {
                await Task.Run(() =>
                {
                    matchingCustomers = customerDAL.GetCustomersByNameDAL(CustomerName);
                });
            }
            catch (Exception)
            {
                throw;
            }
            return matchingCustomers;
        }

        /// <summary>
        /// Gets Customer based on Email.
        /// </summary>
        /// <param name="email">Represents Customer's Email Address.</param>
        /// <returns>Returns Customer object.</returns>
        public async Task<Customer> GetCustomerByEmailBL(string email)
        {
            Customer matchingCustomer = null;
            try
            {
                await Task.Run(() =>
                {
                    matchingCustomer = customerDAL.GetCustomerByEmailDAL(email);
                });
            }
            catch (Exception)
            {
                throw;
            }
            return matchingCustomer;
        }
        /// <summary>
        /// Gets Customer based on Mobile Number.
        /// </summary>
        /// <param name="mobile">Represents Customer's mobile number.</param>
        /// <returns>Returns Customer object.</returns>
        public async Task<Customer> GetCustomerByCustomerMobileBL(string mobile)
        {
            Customer matchingCustomer = null;
            try
            {
                await Task.Run(() =>
                {
                    matchingCustomer = customerDAL.GetCustomerByCustomerMobileDAL(mobile);
                });
            }
            catch (Exception)
            {
                throw;
            }
            return matchingCustomer;
        }
        /// <summary>
        /// Gets Customer based on Aadhar Number.
        /// </summary>
        /// <param name="aadhar">Represents Customer's Aadhar Number.</param>
        /// <returns>Returns Customer object.</returns>
        public async Task<Customer> GetCustomerByCustomerAadharNumberBL(string aadhar)
        {
            Customer matchingCustomer = null;
            try
            {
                await Task.Run(() =>
                {
                    matchingCustomer = customerDAL.GetCustomerByCustomerAadharNumberDAL(aadhar);
                });
            }
            catch (Exception)
            {
                throw;
            }
            return matchingCustomer;
        }
        /// <summary>
        /// Gets Customer based on PAN number.
        /// </summary>
        /// <param name="pan">Represents Customer's PAN number.</param>
        /// <returns>Returns Customer object.</returns>
        public async Task<Customer> GetCustomerByCustomerPANNumberBL(string pan)
        {
            Customer matchingCustomer = null;
            try
            {
                await Task.Run(() =>
                {
                    matchingCustomer = customerDAL.GetCustomerByCustomerPANNumberDAL(pan);
                });
            }
            catch (Exception)
            {
                throw;
            }
            return matchingCustomer;
        }


        /// <summary>
        /// Updates Customer based on CustomerNumber.
        /// </summary>
        /// <param name="updateCustomer">Represents Customer details including Customermobile, CustomerName etc.</param>
        /// <returns>Determinates whether the existing Customer is updated.</returns>
        public async Task<bool> UpdateCustomerBL(Customer updateCustomer)
        {
            bool CustomerUpdated = false;
            try
            {
                if ((await Validate(updateCustomer)) && (await GetCustomerByCustomerNumberBL(updateCustomer.CustomerNumber)) != null)
                {
                    this.customerDAL.UpdateCustomerDAL(updateCustomer);
                    CustomerUpdated = true;
                    Serialize();
                }
            }
            catch (Exception)
            {
                throw;
            }
            return CustomerUpdated;
        }

        /// <summary>
        /// Disposes DAL object(s).
        /// </summary>
        public void Dispose()
        {
            ((CustomerDAL)customerDAL).Dispose();
        }

        /// <summary>
        /// Invokes Serialize method of DAL.
        /// </summary>
        public static void Serialize()
        {
            try
            {
                CustomerDALBase.Serialize();
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        ///Invokes Deserialize method of DAL.
        /// </summary>
        public static void Deserialize()
        {
            try
            {
                CustomerDALBase.Deserialize();
            }
            catch (Exception)
            {
                throw;
            }
        }
    }

}
