﻿using Pecunia.Entities;
using Pecunia.BusinessLayer;
using Pecunia.Contracts.BLContracts;
using Pecunia.Exceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;


namespace Pecunia.PresentationLayer
{
    class AccountPresentation
    {
        /// <summary>
        /// Menu for Accounts Service
        /// </summary>
        /// <returns></returns>
        public static async Task<int> AccountMenu()
        {
            int choice = -1;

            do
            {
                //Menu
                WriteLine("\n***********Accounts Menu***********");
                WriteLine("1. Create new account");
                WriteLine("2. Update/Modify account");
                WriteLine("3. Delete account");
                WriteLine("4. Search account");
                WriteLine("0. Logout");
                WriteLine("-1. Exit");
                Write("choice");
                //Accept and check choice
                bool isValidChoice = int.TryParse(ReadLine(), out choice);
                if (isValidChoice)
                {
                    switch (choice)
                    {
                        case 1:
                            await CreateAccount();
                            break;
                        case 2:
                            //await UpdateAccount();
                            break;
                        case 3:
                            //await DeleteAccount();
                            break;
                        case 4:
                            await SearchAccount();
                            break;
                        case 0: break;

                    }
                }
                else
                {
                    choice = -1;
                }
            } while (choice != 0);
            return choice;
        }


        /// <summary>
        /// Creating a new account
        /// </summary>
        /// <returns></returns>
        public static async Task CreateAccount()
        {
            CustomerBL cbl = new CustomerBL();
            RegularAccountBL abl = new RegularAccountBL();
            //FixedBL fb = new FixedBL();
            try
            {
                //Asking whether the customer already exists or not
                WriteLine("Enter 1 for existing customer\n");
                WriteLine("Enter 2 for new customer\n");
                int ch = Convert.ToInt32(Console.ReadLine());

                //When the customer already exists
                if (ch == 1)
                {
                    Console.WriteLine("Enter Customer No :");
                    string searchCustomerNo = Console.ReadLine();
                    Customer customer = await cbl.GetCustomerByCustomerNumberBL(searchCustomerNo);
                    Console.WriteLine("Select the type of account(Savings, Current or Fixed) :");
                    string accType = Console.ReadLine();
                    if (customer != null)
                    {
                        if ((accType.Equals("Savings", StringComparison.OrdinalIgnoreCase)) || (accType.Equals("Current", StringComparison.OrdinalIgnoreCase)))
                        {
                            RegularAccount account = new RegularAccount();
                            WriteLine("Enter a Branch: ");
                            account.Branch = Console.ReadLine();
                            //account.CustomerNo = searchCustomerNo;
                            account.AccountType = accType;
                            //Write("Enter AccountNo.");
                            //account.AccountNo = ReadLine();
                            bool isAdded = await abl.CreateAccountBL(account);
                            if (isAdded)
                                Console.WriteLine(accType + " account created");
                            else
                                Console.WriteLine("Account not created");

                        }

                       /* if (accType.Equals("Fixed", StringComparison.OrdinalIgnoreCase))
                        {
                            Fixed fixedacc = new Fixed();
                            WriteLine("Enter a Branch: ");
                            fixedacc.Branch = Console.ReadLine();
                            fixedacc.CustomerNo = searchCustomerNo;
                            WriteLine("Enter Tenure");
                            fixedacc.Tenure = Double.Parse(Console.ReadLine());
                            WriteLine("Enter FDDeposit Amount: ");
                            fixedacc.FDDeposit = Double.Parse(Console.ReadLine());
                            bool fixaccountCreated = await fb.CreateAccountBL(fixedacc);
                            if (fixaccountCreated)
                                Console.WriteLine("Fixed account created");
                            else
                                Console.WriteLine("Account not created");
                        }
                        */
                    }
                    else
                    {

                        Console.WriteLine("No Customer Details Available");

                    }

                }

                //When the customer is a new customer
                if (ch == 2)
                {
                    WriteLine("Enter Customer Details :");
                    await CustomerPresentation.AddCustomer();
                    Console.WriteLine("Enter Customer No :");
                    string searchCustomerNo = Console.ReadLine();

                    Customer customer = await cbl.GetCustomerByCustomerNumberBL(searchCustomerNo);
                    Console.WriteLine("Select the type of account(Savings, Current or Fixed) :");
                    string accType = Console.ReadLine();
                    if (customer != null)
                    {
                        if ((accType.Equals("Savings", StringComparison.OrdinalIgnoreCase)) || (accType.Equals("Current", StringComparison.OrdinalIgnoreCase)))
                        {
                            RegularAccount account = new RegularAccount();
                            WriteLine("Enter a Branch: ");
                            account.Branch = Console.ReadLine();
                            //account.CustomerNo = searchCustomerNo;
                            account.AccountType = accType;
                            //Write("Enter AccountNo.");
                            //account.AccountNo = ReadLine();
                            bool isAdded = await abl.CreateAccountBL(account);
                            if (isAdded)
                                Console.WriteLine(accType + " account created");
                            else
                                Console.WriteLine("Account not created");

                        }

                       /* if (accType.Equals("Fixed", StringComparison.OrdinalIgnoreCase))
                        {
                            Fixed fixedacc = new Fixed();
                            WriteLine("Enter a Branch: ");
                            fixedacc.Branch = Console.ReadLine();
                            WriteLine("Enter Tenure: ");
                            fixedacc.Tenure = Double.Parse(Console.ReadLine());
                            WriteLine("Enter FDDeposit Amount: ");
                            fixedacc.FDDeposit = Double.Parse(Console.ReadLine());

                            fixedacc.CustomerNo = searchCustomerNo;
                            bool fixaccountCreated = await fb.CreateAccountBL(fixedacc);
                            if (fixaccountCreated)
                                Console.WriteLine("Fixed account created");
                            else
                                Console.WriteLine("Account not created");
                        }
                        */


                    }

                }
            }
            catch (Exception ex)
            {
                ExceptionLogger.LogException(ex);
                WriteLine(ex.Message);
            }
        }






/*

        /// <summary>
        /// Updating the account branch or modifying the account branch
        /// </summary>
        /// <returns></returns>
        public static async Task UpdateAccount()
        {
            AccountBL ab = new AccountBL();
            FixedBL fb = new FixedBL();
            try
            {
                Console.WriteLine("Enter 1 for updating branch \n");
                Console.WriteLine("Enter 2 for modifying account type \n");
                int cha = Convert.ToInt32(Console.ReadLine());
                switch (cha)
                {
                    case 1:

                        Console.WriteLine("Enter the account number :\n");
                        string accno = Console.ReadLine();

                        RegularAccount account = await ab.SearchAccountByAccountNoBL(accno);
                        if (account != null)
                        {
                            Console.WriteLine("Enter the new account branch :\n");
                            string branch = Console.ReadLine();
                            bool accountBranchUpdated = await ab.UpdateBranchBL(accno, branch);
                            if (accountBranchUpdated)
                                Console.WriteLine("Home branch updated");
                            else
                                Console.WriteLine("Home branch not Updated ");
                        }

                        Fixed fixacc = await fb.SearchAccountByAccountNoBL(accno);
                        if (fixacc != null)
                        {
                            Console.WriteLine("Enter the new account branch :\n");
                            string branch = Console.ReadLine();
                            bool accountBranchUpdated = await fb.UpdateBranchBL(accno, branch);
                            if (accountBranchUpdated)
                                Console.WriteLine("Home branch updated");
                            else
                                Console.WriteLine("Home branch not Updated ");
                        }

                        else
                        {
                            Console.WriteLine("No customer Details Available");
                        }

                        break;

                    case 2:

                        Console.WriteLine("Enter the account number :\n");
                        string accno2 = Console.ReadLine();
                        RegularAccount account1 = await ab.SearchAccountByAccountNoBL(accno2);
                        if (account1 != null)
                        {
                            Console.WriteLine("Enter the new account type(Savings or Current) :\n");
                            string acctype = Console.ReadLine();
                            account1.AccountType = acctype;
                            bool accountTypeUpdated = await ab.UpdateAccountTypeBL(accno2, acctype);
                            if (accountTypeUpdated)
                                Console.WriteLine("Account type updated");
                            else
                                Console.WriteLine("Account type not Updated ");
                        }

                        else
                        {
                            Console.WriteLine("No customer Details Available");
                        }

                        break;

                }
            }
            catch (PecuniaException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        /// <summary>
        /// Deleting an existing account
        /// </summary>
        /// <returns></returns>
        public static async Task DeleteAccount()
        {
            AccountBL ab = new AccountBL();
            FixedBL fb = new FixedBL();
            try
            {

                Console.WriteLine("Enter the account number :\n");
                string accno = Console.ReadLine();
                if (accno.Substring(0, 1) == "1")
                {
                    RegularAccount account = await ab.SearchAccountByAccountNoBL(accno);
                    if (account != null)
                    {

                        bool accountDeleted = await ab.DeleteAccountBL(accno);
                        if (accountDeleted)
                            Console.WriteLine("Account deleted");
                        else
                            Console.WriteLine("Account not deleted");
                    }

                    else
                    {
                        Console.WriteLine("No customer details available");
                    }
                }
                if (accno.Substring(0, 1) == "2")
                {
                    Fixed fixacc = await fb.SearchAccountByAccountNoBL(accno);
                    if (fixacc != null)
                    {

                        bool accountDeleted = await fb.DeleteAccountBL(accno);
                        if (accountDeleted)
                            Console.WriteLine("Account deleted");
                        else
                            Console.WriteLine("Account not deleted");
                    }

                    else
                    {
                        Console.WriteLine("No customer details available");
                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionLogger.LogException(ex);
                WriteLine(ex.Message);
            }
        }


 */
        /// <summary>
        /// Searching the accounts based on various criteria
        /// </summary>
        /// <returns>Returns Account or Fixed object</returns>
        public static async Task SearchAccount()
        {
            CustomerBL cb = new CustomerBL();
            RegularAccountBL ab = new RegularAccountBL();
            FixedBL Fb = new FixedBL();
            try
            {
                Console.WriteLine("1.Search account by account number:");
                Console.WriteLine("2.Search accounts by CustomerNo:");
                Console.WriteLine("3.Search accounts by account type:");
                Console.WriteLine("4.Search account by home branch:");
                Console.WriteLine("5.Search account by date:");

                int option = Convert.ToInt32(Console.ReadLine());
                switch (option)
                {
                    case 1:

                        string accno;
                        Console.WriteLine("Enter account number to search:");
                        
                        accno = Console.ReadLine();
                        if (accno.Substring(0, 1) == "1")
                        {
                            RegularAccount account1 = await ab.GetAccountByAccountNoBL(accno);
                            Guid customID = account1.CustomerID;
                            //AccountsByCustNo.AddRange(regularAccountList.FindAll(x => x.CustomerID == searchCustID));
                            Customer c = await cb.GetAllCustomersBL().(Find(x => x.CustomerID == customID));
                            Guid searchCustID = c.CustomerID;
                            if (account1 != null)
                            {
                                Console.WriteLine("*******************************************************************************************************");
                                Console.WriteLine("Customer No\tAccount Number\tAccount Type\tCurrent Balance\tBranch\tStatus\tCreation Date\tLast Modified");
                                Console.WriteLine("*******************************************************************************************************");
                                Console.WriteLine($"\t {account1.AccountNo}\t {account1.AccountType}\t { account1.CurrentBalance}\t{ account1.Branch}\t {account1.Status}\t {account1.CreationDateTime}\t{ account1.LastModifiedDateTime}");
                                Console.WriteLine("*******************************************************************************************************");
                            }
                            else
                            {
                                Console.WriteLine("No Account Details Available");
                            }


                        }
                        if (accno.Substring(0, 1) == "2")
                        {
                            Fixed acc = await Fb.SearchAccountByAccountNoBL(accno);
                            if (acc != null)
                            {
                                Console.WriteLine("***************************************************************************************************************************");
                                Console.WriteLine("Customer No\tAccount Number\tAccount Type\tCurrent Balance\tBranch\tStatus\tTenure\tFDDeposit\tCreation Date\tLast Modified");
                                Console.WriteLine("***************************************************************************************************************************");
                                Console.WriteLine($"{acc.CustomerNo}\t {acc.AccountNo}\t {acc.AccountType}\t { acc.CurrentBalance}\t{ acc.Branch}\t {acc.Status}\t{acc.Tenure}\t{acc.FDDeposit}\t{acc.CreationDateTime}\t{ acc.LastModifiedDateTime}");

                                Console.WriteLine("**************************************************************************************************************************");
                            }
                            else
                            {
                                Console.WriteLine("No Account Details Available");
                            }
                        }


                        break;

                    case 2:


                        string custNo;
                        Console.WriteLine("Enter customer No to search:");
                        custNo = Console.ReadLine();
                        List<Fixed> fixaccountsbycustNo = await Fb.GetAccountsByCustomerNoBL(custNo);

                        List<RegularAccount> accountsbycustNo = await ab.GetAccountsByCustomerNoBL(custNo);
                        if (accountsbycustNo != null)
                        {
                            Console.WriteLine("*******************************************************************************************************");
                            Console.WriteLine("Customer No\tAccount Number\tAccount Type\tCurrent Balance\tBranch\tStatus\tCreation Date\tLast Modified");
                            Console.WriteLine("*******************************************************************************************************");
                            foreach (RegularAccount account1 in accountsbycustNo)
                            {
                                Console.WriteLine($"{account1.CustomerNo}\t {account1.AccountNo}\t {account1.AccountType}\t { account1.CurrentBalance}\t{ account1.Branch}\t {account1.Status}\t {account1.CreationDateTime}\t{ account1.LastModifiedDateTime}");
                            }
                            Console.WriteLine("*******************************************************************************************************");
                        }


                        else if (fixaccountsbycustNo != null)
                        {
                            Console.WriteLine("***************************************************************************************************************************");
                            Console.WriteLine("Customer No\tAccount Number\tAccount Type\tCurrent Balance\tBranch\tStatus\tTenure\tFDDeposit\tCreation Date\tLast Modified");
                            Console.WriteLine("***************************************************************************************************************************");
                            foreach (Fixed acc in fixaccountsbycustNo)
                            {
                                Console.WriteLine($"{acc.CustomerNo}\t {acc.AccountNo}\t {acc.AccountType}\t { acc.CurrentBalance}\t{ acc.Branch}\t {acc.Status}\t{acc.Tenure}\t{acc.FDDeposit}\t{acc.CreationDateTime}\t{ acc.LastModifiedDateTime}");
                            }
                            Console.WriteLine("**************************************************************************************************************************");

                        }

                        else
                        {
                            Console.WriteLine("No Customer Details Available");
                        }


                        break;


                    case 3:

                        string accType;
                        Console.WriteLine("Enter account type to search:");
                        accType = Console.ReadLine();

                        if ((accType == "Savings") || (accType == "Current"))
                        {
                            List<RegularAccount> accountsbytype = await ab.GetAccountsByTypeBL(accType);
                            if (accountsbytype != null)
                            {
                                Console.WriteLine("*******************************************************************************************************");
                                Console.WriteLine("Customer No\tAccount Number\tAccount Type\tCurrent Balance\tBranch\tStatus\tCreation Date\tLast Modified");
                                Console.WriteLine("*******************************************************************************************************");
                                foreach (RegularAccount account1 in accountsbytype)
                                {
                                    Console.WriteLine($"{account1.CustomerNo}\t {account1.AccountNo}\t {account1.AccountType}\t { account1.CurrentBalance}\t{ account1.Branch}\t {account1.Status}\t {account1.CreationDateTime}\t{ account1.LastModifiedDateTime}");
                                }
                                Console.WriteLine("*******************************************************************************************************");
                            }
                            else
                            {
                                Console.WriteLine("No Accounts Available");
                            }
                        }
                        if (accType == "Fixed")
                        {
                            List<Fixed> fixaccounts = await Fb.GetAllAccountsBL();
                            if (fixaccounts != null)
                            {
                                Console.WriteLine("***************************************************************************************************************************");
                                Console.WriteLine("Customer No\tAccount Number\tAccount Type\tCurrent Balance\tBranch\tStatus\tTenure\tFDDeposit\tCreation Date\tLast Modified");
                                Console.WriteLine("***************************************************************************************************************************");
                                foreach (Fixed acc in fixaccounts)
                                {
                                    Console.WriteLine($"{acc.CustomerNo}\t {acc.AccountNo}\t {acc.AccountType}\t { acc.CurrentBalance}\t{ acc.Branch}\t {acc.Status}\t{acc.Tenure}\t{acc.FDDeposit}\t{acc.CreationDateTime}\t{ acc.LastModifiedDateTime}");
                                }
                                Console.WriteLine("**************************************************************************************************************************");

                            }

                            else
                            {
                                Console.WriteLine("No Accounts Available");
                            }
                        }


                        break;

                    case 4:

                        string branch;
                        Console.WriteLine("Enter home branch to search:");
                        branch = Console.ReadLine();
                        List<Fixed> fixaccountsbybranch = await Fb.GetAccountsByBranchBL(branch);

                        List<RegularAccount> accountsbybranch = await ab.GetAccountsByBranchBL(branch);
                        if (accountsbybranch != null)
                        {
                            Console.WriteLine("*******************************************************************************************************");
                            Console.WriteLine("Customer No\tAccount Number\tAccount Type\tCurrent Balance\tBranch\tStatus\tCreation Date\tLast Modified");
                            Console.WriteLine("*******************************************************************************************************");
                            foreach (RegularAccount account1 in accountsbybranch)
                            {
                                Console.WriteLine($"{account1.CustomerNo}\t {account1.AccountNo}\t {account1.AccountType}\t { account1.CurrentBalance}\t{ account1.Branch}\t {account1.Status}\t {account1.CreationDateTime}\t{ account1.LastModifiedDateTime}");
                            }
                            Console.WriteLine("*******************************************************************************************************");
                        }


                        else if (fixaccountsbybranch != null)
                        {
                            Console.WriteLine("***************************************************************************************************************************");
                            Console.WriteLine("Customer No\tAccount Number\tAccount Type\tCurrent Balance\tBranch\tStatus\tTenure\tFDDeposit\tCreation Date\tLast Modified");
                            Console.WriteLine("***************************************************************************************************************************");
                            foreach (Fixed acc in fixaccountsbybranch)
                            {
                                Console.WriteLine($"{acc.CustomerNo}\t {acc.AccountNo}\t {acc.AccountType}\t { acc.CurrentBalance}\t{ acc.Branch}\t {acc.Status}\t{acc.Tenure}\t{acc.FDDeposit}\t{acc.CreationDateTime}\t{ acc.LastModifiedDateTime}");
                            }
                            Console.WriteLine("**************************************************************************************************************************");
                        }


                        else
                        {
                            Console.WriteLine("No Customer Details Available");
                        }

                        break;


                    case 5:

                        DateTime date1;
                        DateTime date2;
                        Console.WriteLine("Enter the range of dates to search:");
                        date1 = Convert.ToDateTime(Console.ReadLine());
                        date2 = Convert.ToDateTime(Console.ReadLine());
                        break;

                        List<Fixed> fixaccountsbydate = await Fb.GetAccountsByAccountOpeningDateBL(date1, date2);
                        List<RegularAccount> accountsbydate = await ab.GetAccountsByAccountOpeningDateBL(date1, date2);
                        if (accountsbydate != null)
                        {
                            Console.WriteLine("*******************************************************************************************************");
                            Console.WriteLine("Customer No\tAccount Number\tAccount Type\tCurrent Balance\tBranch\tStatus\tCreation Date\tLast Modified");
                            Console.WriteLine("*******************************************************************************************************");
                            foreach (RegularAccount account1 in accountsbydate)
                            {
                                Console.WriteLine($"{account1.CustomerNo}\t {account1.AccountNo}\t {account1.AccountType}\t { account1.CurrentBalance}\t{ account1.Branch}\t {account1.Status}\t {account1.CreationDateTime}\t{ account1.LastModifiedDateTime}");
                            }
                            Console.WriteLine("*******************************************************************************************************");
                        }


                        else if (fixaccountsbydate != null)
                        {
                            Console.WriteLine("***************************************************************************************************************************");
                            Console.WriteLine("Customer No\tAccount Number\tAccount Type\tCurrent Balance\tBranch\tStatus\tTenure\tFDDeposit\tCreation Date\tLast Modified");
                            Console.WriteLine("***************************************************************************************************************************");
                            foreach (Fixed acc in fixaccountsbydate)
                            {
                                Console.WriteLine($"{acc.CustomerNo}\t {acc.AccountNo}\t {acc.AccountType}\t { acc.CurrentBalance}\t{ acc.Branch}\t {acc.Status}\t{acc.Tenure}\t{acc.FDDeposit}\t{acc.CreationDateTime}\t{ acc.LastModifiedDateTime}");
                            }
                            Console.WriteLine("**************************************************************************************************************************");

                        }


                        else
                        {
                            Console.WriteLine("No accounts available for these dates");
                        }
                        break;

                }

            }
            catch (Exception ex)
            {
                ExceptionLogger.LogException(ex);
                WriteLine(ex.Message);
            }
        }
    }
}