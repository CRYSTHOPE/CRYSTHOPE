﻿using Pecunia.Entities;
using Pecunia.BusinessLayer;
using Pecunia.Contracts.BLContracts;
using Pecunia.Exceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;


namespace Pecunia.PresentationLayer
{
    
    
        public static class UtilitiesPresentation
        {
            /// <summary>
            /// Menu for Utilities
            /// </summary>
            /// <returns></returns>
            public static async Task<int> UtilitiesMenu()
            {
                int choice = -2;

                do
                {
                    //Menu
                    WriteLine("\n***************Employee***********");
                    WriteLine("1. View DebitCards List");
                    WriteLine("2. Add DebitCard");
                    WriteLine("3. Search DebitCard By AccountId");
                    WriteLine("4. Update DebitCard Status");
                    WriteLine("-----------------------");
                    WriteLine("5. View CreditCardsist");
                    WriteLine("6. Add CreditCard");
                    WriteLine("7. Search CreditCard By CustomerId");
                    WriteLine("8. Update CreditCard Status");
                    WriteLine("-----------------------");
                    WriteLine("9. View Cheque Books List");
                    WriteLine("10. Add ChequeBook Request");
                    WriteLine("11. Search ChequeBook By ChequeBookId");
                    WriteLine("12. Update ChequeBook Status");
                    WriteLine("-----------------------");
                    WriteLine("0. Logout");
                    WriteLine("-1. Exit");
                    Write("Choice: ");
                    //Accept and check choice
                    bool isValidChoice = int.TryParse(ReadLine(), out choice);
                    if (isValidChoice)
                    {
                        switch (choice)
                        {
                            case 1: await ViewDebitCardsList(); break;
                            case 2: await AddDebitCard(); break;
                            case 3: await SearchDebitCardByAccountId(); break;
                            case 4: await UpdateDebitCardStatus(); break;

                            case 5: await ViewCreditCardsList(); break;
                            case 6: await AddCreditCard(); break;
                            case 7: await SearchCreditCardByCustomerId(); break;
                            case 8: await UpdateCreditCardStatus(); break;

                            case 9: await ViewChequeBooksList(); break;
                            case 10: await AddChequeBook(); break;
                            case 11: await SearchChequeBookByAccountId(); break;
                            case 12: await UpdateChequeBookStatus(); break;

                        }
                    }
                    else
                    {
                        choice = -2;
                    }
                } while (choice != 0 && choice != -1);
                return choice;
            }

            #region DebitCard

            /// <summary>
            /// Displays list of DebitCards.
            /// </summary>
            /// <returns></returns>
            public static async Task ViewDebitCardsList()
            {
                try
                {
                    using (IDebitCardBL idebitCardBL = new DebitCardBL())
                    {
                        //Get and display list of debit cards.
                        List<DebitCard> debitCards = await idebitCardBL.GetAllDebitCardsBL();
                        WriteLine("DebitCards List:");
                        if (debitCards != null && debitCards?.Count > 0)
                        {
                            WriteLine("#\tNameOnCard\tCardNumber\tExpiryDate\tCardStatus\tCardType");
                            int serial = 0;
                            foreach (var debitCard in debitCards)
                            {
                                serial++;
                                WriteLine($"{serial}\t{debitCard.CustomerNameAsPerCard}\t{debitCard.CardNumber}\t{debitCard.ExpiryMMYYYY}\t{debitCard.CardStatus}\t{debitCard.CardType}");
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    ExceptionLogger.LogException(ex);
                    WriteLine(ex.Message);
                }
            }
            /// <summary>
            /// Adds DebitCard.
            /// </summary>
            /// <returns></returns>
            public static async Task AddDebitCard()
            {
                try
                {
                    //Read inputs
                    DebitCard debitCard = new DebitCard();
                    WriteLine("Name On Card: ");
                    debitCard.CustomerNameAsPerCard = ReadLine();
                    WriteLine("Debit Card Type:");
                    debitCard.CardType = ReadLine();
                    WriteLine("Enter Account Number");
                string accountNo = ReadLine();   
                AccountBL accountBL = new AccountBL();
                RegularAccount account = new RegularAccount();
                account = await accountBL.SearchAccountByAccountNoBL( accountNo);
                if (account != null)
                {
                    debitCard.AccountId = account.AccountID;
                }
                else
                {
                    WriteLine("Respective account not found");
                    return;
                }
                //Invoke AddDebitCardBL method to add
                using (IDebitCardBL debitCardBL = new DebitCardBL())
                    {
                        bool isAdded = await debitCardBL.AddDebitCardBL(debitCard);
                        if (isAdded)
                        {
                            WriteLine("DebitCard Added");
                        }
                    }
                }
                catch (Exception ex)
                {
                    ExceptionLogger.LogException(ex);
                    WriteLine(ex.Message);
                }
            }
            /// <summary>
            /// Searches DebitCard By AccountId.
            /// </summary>
            /// <returns></returns>
            public static async Task SearchDebitCardByAccountId()
            {
                try
                {
                    //Read inputs

                    WriteLine("Enter account number ");
                    string AccountNo = ReadLine();
                    AccountBL accountBL = new AccountBL();
                    RegularAccount account = new RegularAccount();
                    account = await accountBL.SearchAccountByAccountNoBL(AccountNo);

                    //Invoke SearchDebitCardByAccountIdBL method to search
                    using (IDebitCardBL debitCardBL = new DebitCardBL())
                    {
                        List<DebitCard> debitCardsByAccountID = new List<DebitCard>();
                        debitCardsByAccountID = await debitCardBL.GetDebitCardsByAccountIdBL(account.AccountID);
                        if (debitCardsByAccountID != null)
                        {
                            WriteLine("Debit card found ");
                            WriteLine("#\tNameOnCard\tCardNumber\tExpiryDate\tCardStatus\tCardType");
                            int serial = 0;
                            foreach (var debitCard in debitCardsByAccountID)
                            {
                                serial++;
                                WriteLine($"{serial}\t{debitCard.CustomerNameAsPerCard}\t{debitCard.CardNumber}\t{debitCard.ExpiryMMYYYY}\t{debitCard.CardStatus}\t{debitCard.CardType}");
                            }
                        }
                        else
                        {
                            WriteLine("Debbit card not found");
                        }
                    }
                }
                catch (Exception ex)
                {
                    ExceptionLogger.LogException(ex);
                    WriteLine(ex.Message);
                }
            }
            /// <summary>
            /// Updates DebitCardStatus.
            /// </summary>
            /// <returns></returns>
            public static async Task UpdateDebitCardStatus()
            {
                try
                {
                    //Read inputs

                    WriteLine("Enter card number ");
                    string cardNo = ReadLine();
                    WriteLine("Enter the status to be updated as per request from user ");
                    string cardStatus = ReadLine();
                    

                    //Invoke UpdateDebitCardStatusBL to update the status
                    using (IDebitCardBL debitCardBL = new DebitCardBL())
                    {
                        bool statusUpdated;
                        statusUpdated = await debitCardBL.UpdateDebitCardStatusBL(cardNo, cardStatus);
                        if (statusUpdated)
                        {
                            WriteLine("DebitCard status updated ");
                        }

                    }
                }
                catch (Exception ex)
                {
                    ExceptionLogger.LogException(ex);
                    WriteLine(ex.Message);
                }
            }

            #endregion  DebitCard


            #region CreditCard

            /// <summary>
            /// Displays list of DebitCards.
            /// </summary>
            /// <returns></returns>
            public static async Task ViewCreditCardsList()
            {
                try
                {
                    using (iCreditCardBL icreditCardBL = new CreditCardBL())
                    {
                        //Get and display list of credit cards.
                        List<CreditCard> creditCards = await icreditCardBL.GetAllCreditCardsBL();
                        WriteLine("CreditCards List:");
                        if (creditCards != null && creditCards?.Count > 0)
                        {
                            WriteLine("#\tNameOnCard\tCardNumber\tExpiryDate\tCardStatus\tCreditLimit");
                            int serial = 0;
                            foreach (var creditCard in creditCards)
                            {
                                serial++;
                                WriteLine($"{serial}\t{creditCard.CustomerNameAsPerCard}\t{creditCard.CardNumber}\t{creditCard.ExpiryMMYYYY}\t{creditCard.CardStatus}\t{creditCard.CreditLimit}");
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    ExceptionLogger.LogException(ex);
                    WriteLine(ex.Message);
                }
            }
            /// <summary>
            /// Adds CreditCard.
            /// </summary>
            /// <returns></returns>
            public static async Task AddCreditCard()
            {
                try
                {
                    //Read inputs
                    CreditCard creditCard = new CreditCard();
                    WriteLine("Name On Card: ");
                    creditCard.CustomerNameAsPerCard = ReadLine();
                    WriteLine("Credit Card Type:");
                    creditCard.CardType = ReadLine();
                    WriteLine("Enter Customer Number");
                    string customerNo = ReadLine();
                CustomerBL customerBL = new CustomerBL();
                Customer cust = new Customer();
                cust= await customerBL.GetCustomerByCustomerNumberBL(customerNo);
                creditCard.CreditLimit = cust.AnnualIncome / 6;
                if (cust != null)
                {
                    creditCard.CustomerId = cust.CustomerID;
                }
                else
                {
                    WriteLine("Invalid customer number");
                    return;
                }

                //Invoke AddCreditCardBL method to add
                using (iCreditCardBL creditCardBL = new CreditCardBL())
                    {
                        bool isAdded = await creditCardBL.AddCreditCardBL(creditCard);
                        if (isAdded)
                        {
                            WriteLine("CreditCard Added");
                        }
                    }
                }
                catch (Exception ex)
                {
                    ExceptionLogger.LogException(ex);
                    WriteLine(ex.Message);
                }
            }

            public static async Task SearchCreditCardByCustomerId()
            {
                try
                {
                    //Read inputs

                    WriteLine("Enter customer number ");
                    string CustomerNo = ReadLine();
                    CustomerBL customerBL = new CustomerBL();
                    Customer customer = new Customer();
                    customer =await  customerBL.GetCustomerByCustomerNumberBL(CustomerNo);


                    //Invoke SearchDebitCardByAccountIdBL method to search
                    using (iCreditCardBL creditCardBL = new CreditCardBL())
                    {
                        List<CreditCard> creditCardsByCustomerNo = new List<CreditCard>();
                        creditCardsByCustomerNo = await creditCardBL.GetCreditCardsByCustomerIdBL(customer.CustomerID);
                        if (creditCardsByCustomerNo != null)
                        {
                            WriteLine("CreditCard found ");
                            WriteLine("#\tNameOnCard\tCardNumber\tExpiryDate\tCardStatus\tCardType");
                            int serial = 0;
                            foreach (var creditCard in creditCardsByCustomerNo)
                            {
                                serial++;
                                WriteLine($"{serial}\t{creditCard.CustomerNameAsPerCard}\t{creditCard.CardNumber}\t{creditCard.ExpiryMMYYYY}\t{creditCard.CardStatus}\t{creditCard.CardType}");
                            }
                        }
                        else
                        {
                            WriteLine("CreditCard Not found ");
                        }
                    }
                }
                catch (Exception ex)
                {
                    ExceptionLogger.LogException(ex);
                    WriteLine(ex.Message);
                }
            }
            public static async Task UpdateCreditCardStatus()
            {
                try
                {
                //Read inputs
                WriteLine("Customer Number:");
                string custNo = ReadLine();
                WriteLine("Enter card number ");
                    string cardNo = ReadLine();
                    WriteLine("Enter the status to be updated as per request from user ");
                    string cardStatus = ReadLine();
                    CustomerBL customerBL = new CustomerBL();
                    Customer customer = new Customer();
                    customer = await customerBL.GetCustomerByCustomerNumberBL(custNo);
                //Invoke UpdateCreditCardStatusBL to update the status
                if (customer != null)
                {
                    using (iCreditCardBL creditCardBL = new CreditCardBL())
                    {
                        bool statusUpdated;
                        statusUpdated = await creditCardBL.UpdateCreditCardStatusBL(cardNo, cardStatus);
                        if (statusUpdated)
                        {
                            WriteLine("CreditCard status updated ");
                        }

                    }
                }
                }
                catch (Exception ex)
                {
                    ExceptionLogger.LogException(ex);
                    WriteLine(ex.Message);
                }
            }
            #endregion CreditCard
            #region ChequeBook
            /// <summary>
            /// Displays list of ChequeBooks.
            /// </summary>
            /// <returns></returns>
            public static async Task ViewChequeBooksList()
            {
                try
                {
                    using (iChequeBookBL ichequeBookBL = new ChequeBookBL())
                    {
                        //Get and display list of cheque books.
                        List<ChequeBook> chequeBooks = await ichequeBookBL.GetAllChequeBooksBL();
                        WriteLine("ChequeBooks List:");
                        if (chequeBooks != null && chequeBooks?.Count > 0)
                        {
                            WriteLine("#\tAccountNumber\tNumberOfLeaves\tSeriesStart\tStatus");
                            int serial = 0;
                            foreach (var chequeBook in chequeBooks)
                            {
                                serial++;
                                WriteLine($"{serial}\t{chequeBook.AccountNo}\t{chequeBook.NumberOfLeaves}\t{chequeBook.SeriesStart}\t{chequeBook.ChequeBookStatus}");
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    ExceptionLogger.LogException(ex);
                    WriteLine(ex.Message);
                }
            }
            /// <summary>
            /// Adds ChequeBook.
            /// </summary>
            /// <returns></returns>
            public static async Task AddChequeBook()
            {
                try
                {
                    //Read inputs
                    ChequeBook chequeBook = new ChequeBook();

                    WriteLine("Enter Account Number");
                    chequeBook.AccountNo = ReadLine();
                    WriteLine("Series starts from");
                    chequeBook.SeriesStart = Convert.ToDouble(ReadLine());
                    WriteLine("Enter Number Of Leaves");
                    chequeBook.NumberOfLeaves = Convert.ToInt32(ReadLine());
                    AccountBL accountBL = new AccountBL();
                    RegularAccount account = new RegularAccount();
                    account = await accountBL.SearchAccountByAccountNoBL(chequeBook.AccountNo);
                    chequeBook.AccountId = account.AccountID;
                    //Invoke AddChequeBookBL method to add
                    using (iChequeBookBL chequeBookBL = new ChequeBookBL())
                    {
                        bool isAdded = await chequeBookBL.AddChequeBookBL(chequeBook);
                        if (isAdded)
                        {
                            WriteLine("ChequeBook Requested");
                        }
                    }
                }
                catch (Exception ex)
                {
                    ExceptionLogger.LogException(ex);
                    WriteLine(ex.Message);
                }
            }
            /// <summary>
            /// Searches ChequeBook By AccountId.
            /// </summary>
            /// <returns></returns>
            public static async Task SearchChequeBookByAccountId()
            {
                try
                {
                    //Read inputs

                    WriteLine("Enter account number ");
                    string AccountNo = ReadLine();
                    AccountBL accountBL = new AccountBL();
                    RegularAccount account = new RegularAccount();
                    account = await accountBL.SearchAccountByAccountNoBL(AccountNo);

                    //Invoke SearchChequeBooksByAccountIdBL method to search
                    using (iChequeBookBL chequeBookBL = new ChequeBookBL())
                    {
                        List<ChequeBook> chequeBooksByAccountID = new List<ChequeBook>();
                        chequeBooksByAccountID = await chequeBookBL.GetChequeBooksByAccountIdBL(account.AccountID);
                        if (chequeBooksByAccountID != null)
                        {
                            WriteLine("ChequeBook found ");
                            WriteLine("#\tAccountNumber\tNumberOfLeaves\tSeriesStart\tStatus");
                            int serial = 0;
                            foreach (var chequeBook in chequeBooksByAccountID)
                            {
                                serial++;
                                WriteLine($"{serial}\t{chequeBook.AccountNo}\t{chequeBook.NumberOfLeaves}\t{chequeBook.SeriesStart}\t{chequeBook.ChequeBookStatus}");
                            }
                        }
                        else
                        {
                            WriteLine("ChequeBook not found ");
                        }
                    }
                }
                catch (Exception ex)
                {
                    ExceptionLogger.LogException(ex);
                    WriteLine(ex.Message);
                }
            }
            /// <summary>
            /// Updates ChequeBookStatus.
            /// </summary>
            /// <returns></returns>
            public static async Task UpdateChequeBookStatus()
            {
                try
                {
                    //Read inputs

                    WriteLine("Enter account number ");
                    string accountNo = ReadLine();
                WriteLine("Enter ChequeBook Id ");
                string chequeBookId = ReadLine();
                AccountBL accountBL = new AccountBL();
                    RegularAccount account = new RegularAccount();
                    account = await accountBL.SearchAccountByAccountNoBL(accountNo);

                //Invoke UpdateChequeBookStatusBL to update the status
                if (account != null)
                {
                    using (iChequeBookBL chequeBookBL = new ChequeBookBL())
                    {
                        bool statusUpdated;
                        statusUpdated = await chequeBookBL.UpdateChequeBookStatusBL(chequeBookId);
                        if (statusUpdated)
                        {
                            WriteLine("ChequeBook status updated ");
                        }

                    }
                }
                }
                catch (Exception ex)
                {
                    ExceptionLogger.LogException(ex);
                    WriteLine(ex.Message);
                }
            }
            #endregion ChequeBook

        }
    
}
