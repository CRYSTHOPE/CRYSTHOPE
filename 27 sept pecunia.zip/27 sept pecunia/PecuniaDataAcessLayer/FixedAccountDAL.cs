﻿using Pecunia.Entities;
using Pecunia.Helpers;
using Pecunia.Contracts.DALContracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pecunia.DataAcessLayer
{
    /// <summary>
    /// Contains data access layer methods for creating, updating, deleting account from Accounts collection.
    /// </summary>
    public class FixedDAL : FixedDALBase, IDisposable
    {

        /// <summary>
        /// Adds new account to Accounts collection.
        /// </summary>
        /// <param name="newFixed">Contains the account details to be added.</param>
        /// <returns>Determinates whether the new supplier is added.</returns>
        public override bool CreateAccountDAL(Fixed newFixed)
        {
            bool AccountCreated = false;
            try
            {

                newFixed.AccountID = Guid.NewGuid();
                newFixed.CreationDateTime = DateTime.Now;
                newFixed.LastModifiedDateTime = DateTime.Now;
                newFixed.InterestRate = AccountsConfiguration.interest;
                newFixed.MinimumBalance = AccountsConfiguration.minbal;
                newFixed.CurrentBalance = 0;
                fixedList.Add(newFixed);
                AccountCreated = true;
            }
            catch (Exception)
            {
                throw;
            }
            return AccountCreated;

        }

        /// <summary>
        /// Gets all accounts from the collection.
        /// </summary>
        /// <returns>Returns list of all accounts.</returns>
        public override List<Fixed> GetAllAccountsDAL()
        {
            return fixedList;
        }

        /// <summary>
        /// Gets account based on AccountNo
        /// </summary>
        /// <param name="searchAccountNo">Contains the account no to search the account.</param>
        /// <returns>returns the object of Account Class.</returns>
        public override Fixed SearchAccountByAccountNoDAL(string searchAccountNo)
        {
            Fixed searchAccount = null;
            try
            {
                searchAccount = fixedList.Find(x => x.AccountNo == searchAccountNo);

            }
            catch (Exception)
            {
                throw;
            }
            return searchAccount;
        }


        /// <summary>
        /// Gets list of accounts based on CustomerNo
        /// </summary>
        /// <param name="searchCustomerNo">Contains the Customer No to search the accounts.</param>
        /// <returns>Returns the list of Account class objects where the Customer No matches.</returns>
        public override List<Fixed> GetAccountsByCustomerNoDAL(string searchCustomerNo)
        {
            List<Fixed> AccountsByCustNo = new List<Fixed>();
            try
            {

                AccountsByCustNo.AddRange(fixedList.FindAll(x => x.CustomerNo == searchCustomerNo));

            }
            catch (Exception)
            {
                throw;
            }
            return AccountsByCustNo;
        }


        /// <summary>
        /// Gets list of accounts based on branch
        /// </summary>
        /// <param name="searchBranch">Contains the account in a particular branch.</param>
        /// <returns>Returns the list of Account class objects.</returns>
        public override List<Fixed> GetAccountsByBranchDAL(string searchBranch)
        {
            List<Fixed> AccountsByBranch = new List<Fixed>();
            try
            {
                AccountsByBranch.AddRange(fixedList.FindAll(x => x.Branch == searchBranch));

            }
            catch (Exception)
            {
                throw;
            }
            return AccountsByBranch;
        }

        /// <summary>
        /// Gets list of accounts based on range of dates
        /// </summary>
        /// <param name="d1">Contains the starting date.</param>
        /// <param name="d2">Contains the ending date.</param>
        /// <returns>Returns the list of Account class objects.</returns>
        public override List<Fixed> GetAccountsByAccountOpeningDateDAL(DateTime d1, DateTime d2)
        {
            List<Fixed> AccountsByDate = new List<Fixed>();
            try
            {
                foreach (Fixed item in fixedList)
                {
                    if ((item.CreationDateTime.Ticks >= d1.Ticks) && (item.CreationDateTime.Ticks <= d2.Ticks))
                    {
                        AccountsByDate.AddRange(fixedList);
                    }
                }


            }
            catch (Exception)
            {
                throw;
            }
            return AccountsByDate;
        }

        /// <summary>
        /// Gets Current Balance in the account
        /// </summary>
        /// <param name="accountNumber">Contains the account number for which balance is requested.</param>
        /// <returns>Returns the current balance.</returns>
        public override double GetBalanceDAL(string accountNumber)
        {

            double balance = 0;

            try
            {

                Fixed fixedacc;
                fixedacc = fixedList.Find(x => x.AccountNo == accountNumber);
                balance = fixedacc.CurrentBalance;
            }
            catch (Exception)
            {
                throw;
            }
            return balance;
        }

        /// <summary>
        /// Updates the balance after every transaction
        /// </summary>
        /// <param name="accountNumber">Contains the account number.</param>
        /// <param name="balance">Contains the updated balance after a transaction .</param>
        /// <returns>Determines whether the account balance is updated or not.</returns>
        public override bool UpdateBalanceDAL(string accountNumber, double balance)
        {
            bool BalanceUpdated = false;

            try
            {
                Fixed fixedacc;
                fixedacc = fixedList.Find(x => x.AccountNo == accountNumber);
                /* int now = int.Parse(DateTime.Now.ToString("yyyyMMdd"));
                 int st = int.Parse(account.DateOfAccountOpening.ToString("yyyyMMdd"));
                 double yr = (now - st) / 10000;
                 double si = (balance * account.InterestRate * yr) / 100;*/
                fixedacc.CurrentBalance = balance;
                fixedacc.LastModifiedDateTime = DateTime.Now;
                BalanceUpdated = true;
            }
            catch (Exception)
            {
                throw;
            }

            return BalanceUpdated;
        }

        /// <summary>
        /// Updates the branch of an account
        /// </summary>
        /// <param name="accountNumber">Contains the account number of the account.</param>
        /// <returns>Determines whether the branch is updated or not.</returns>
        public override bool UpdateBranchDAL(string accountNumber, string branch)
        {
            bool AccountBranchUpdated = false;

            try
            {

                Fixed fixedacc;
                fixedacc = fixedList.Find(x => x.AccountNo == accountNumber);
                fixedacc.Branch = branch;
                fixedacc.LastModifiedDateTime = DateTime.Now;
                AccountBranchUpdated = true;
            }
            catch (Exception)
            {
                throw;
            }
            return AccountBranchUpdated;
        }

        /// <summary>
        /// Deletes an existing account
        /// </summary>
        /// <param name="deleteAccountNo">Contains the account number of the account to be deleted.</param>
        /// <returns>Determines whether the account is deleted or not.</returns>
        public override bool DeleteAccountDAL(string deleteAccountNo)
        {
            bool AccountDeleted = false;

            try
            {
                Fixed deleteAccount = null;
                Fixed fixed1;
                fixed1 = fixedList.Find(x => x.AccountNo == deleteAccountNo);
                fixed1.LastModifiedDateTime = DateTime.Now;
                fixed1.Status = "Closed";
                deleteAccount = fixed1;

                if (deleteAccountNo != null)
                {

                    AccountDeleted = true;
                }
            }
            catch (Exception)
            {
                throw;
            }
            return AccountDeleted;

        }

        /// <summary>
        /// Clears unmanaged resources such as db connections or file streams.
        /// </summary>
        /// 
        public void Dispose()
        {
            throw new NotImplementedException();
        }

    }
}
