﻿using Pecunia.Entities;
using Pecunia.Contracts.DALContracts;
using Pecunia.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Pecunia.DataAcessLayer
{
    /// <summary>
    /// Contains data access layer methods for creating, updating, deleting account from Regular Accounts collection.
    /// </summary>
    public class RegularAccountDAL : RegularAccountDALBase, IDisposable
    {

        CustomerDALBase custDAL;

        /// <summary>
        /// Adds new account to Regular Accounts collection.
        /// </summary>
        /// <param name="newAccount">Contains the account details to be added.</param>
        /// <returns>Determinates whether the new account is added.</returns>
        public override bool CreateAccountDAL(RegularAccount newAccount)
        {
            bool AccountCreated = false;
            try
            {
                newAccount.AccountID = Guid.NewGuid();
                newAccount.CreationDateTime = DateTime.Now;
                newAccount.LastModifiedDateTime = DateTime.Now;
                newAccount.InterestRate = AccountsConfiguration.interest;
                newAccount.MinimumBalance = AccountsConfiguration.minbal;
                newAccount.CurrentBalance = 0;
                string path = @"C:\Users\asing472\source\repos\27 sept pecunia\accountnogen.txt";
                string accno = File.ReadAllText(path);
                newAccount.AccountNo = accno;
                long no = Convert.ToInt64(newAccount) + 1;
                string nextaccno = no.ToString();
                File.WriteAllText(path, nextaccno);

                regularAccountList.Add(newAccount);
                AccountCreated = true;
            }
            catch (Exception)
            {
                throw;
            }
            return AccountCreated;

        }

        /// <summary>
        /// Gets all accounts from the collection.
        /// </summary>
        /// <returns>Returns list of all accounts.</returns>
        public override List<RegularAccount> GetAllAccountsDAL()
        {
            return regularAccountList;
        }

        /// <summary>
        /// Gets account based on AccountNo
        /// </summary>
        /// <param name="searchAccountNo">Contains the account no to search the account.</param>
        /// <returns>returns the object of RegularAccount Class.</returns>
        public override RegularAccount GetAccountByAccountNoDAL(string searchAccountNo)
        {
            RegularAccount searchAccount = null;
            try
            {
                searchAccount = regularAccountList.Find(x => x.AccountNo == searchAccountNo);

            }
            catch (Exception)
            {
                throw;
            }
            return searchAccount;
        }


        /// <summary>
        /// Gets list of accounts based on CustomerNo
        /// </summary>
        /// <param name="searchCustomerNo">Contains the Customer No to search the accounts.</param>
        /// <returns>Returns the list of RegularAccount class objects where the Customer No matches.</returns>
        public override List<RegularAccount> GetAccountsByCustomerNoDAL(string searchCustomerNo)
        {
            List<RegularAccount> AccountsByCustNo = new List<RegularAccount>();
            try
            {
                Customer c = custDAL.GetCustomerByCustomerNumberDAL(searchCustomerNo);
                Guid searchCustID = c.CustomerID;
                
                AccountsByCustNo.AddRange(regularAccountList.FindAll(x => x.CustomerID == searchCustID));

            }
            catch (Exception)
            {
                throw;
            }
            return AccountsByCustNo;
        }

        /// <summary>
        /// Gets list of accounts based on Account Type
        /// </summary>
        /// <param name="searchAccountType">Contains the type of regular account(Savings or Current) to search the accounts.</param>
        /// <returns>Returns the list of RegularAccount class objects.</returns>
        public override List<RegularAccount> GetAccountsByTypeDAL(string searchAccountType)
        {
            List<RegularAccount> AccountsByType = new List<RegularAccount>();
            try
            {
                AccountsByType.AddRange(regularAccountList.FindAll(x => x.AccountType == searchAccountType));

            }
            catch (Exception)
            {
                throw;
            }
            return AccountsByType;
        }

        /// <summary>
        /// Gets list of accounts based on branch
        /// </summary>
        /// <param name="searchBranch">Contains the account in a particular branch.</param>
        /// <returns>Returns the list of Regular Account class objects.</returns>
        public override List<RegularAccount> GetAccountsByBranchDAL(string searchBranch)
        {
            List<RegularAccount> AccountsByBranch = new List<RegularAccount>();
            try
            {
                AccountsByBranch.AddRange(regularAccountList.FindAll(x => x.Branch == searchBranch));

            }
            catch (Exception)
            {
                throw;
            }
            return AccountsByBranch;
        }

        /// <summary>
        /// Gets list of accounts based on range of dates
        /// </summary>
        /// <param name="startDate">Contains the starting date.</param>
        /// <param name="endDate">Contains the ending date.</param>
        /// <returns>Returns the list of Regular Account class objects.</returns>
        public override List<RegularAccount> GetAccountsByAccountOpeningDateDAL(DateTime startDate, DateTime endDate)
        {
            List<RegularAccount> AccountsByDate = new List<RegularAccount>();
            try
            {
                foreach (RegularAccount item in regularAccountList)
                {
                    if ((item.CreationDateTime.Ticks >= startDate.Ticks) && (item.CreationDateTime.Ticks <= endDate.Ticks))
                    {
                        AccountsByDate.AddRange(regularAccountList);
                    }
                }


            }
            catch (Exception)
            {
                throw;
            }
            return AccountsByDate;
        }

        /// <summary>
        /// Gets Current Balance in the account
        /// </summary>
        /// <param name="accountNumber">Contains the account number for which balance is requested.</param>
        /// <returns>Returns the current balance.</returns>
        public override double GetBalanceDAL(string accountNumber)
        {

            double balance = 0;

            try
            {
                //Account account = new Account();
                RegularAccount account;
                account = regularAccountList.Find(x => x.AccountNo == accountNumber);
                balance = account.CurrentBalance;
            }
            catch (Exception)
            {
                throw;
            }
            return balance;
        }

        /// <summary>
        /// Updates the balance after every transaction
        /// </summary>
        /// <param name="accountNumber">Contains the account number.</param>
        /// <param name="balance">Contains the updated balance after a transaction .</param>
        /// <returns>Determines whether the account balance is updated or not.</returns>
        public override bool UpdateBalanceDAL(string accountNumber, double balance)
        {
            bool BalanceUpdated = false;

            try
            {
                RegularAccount account;
                account = regularAccountList.Find(x => x.AccountNo == accountNumber);
                /* int now = int.Parse(DateTime.Now.ToString("yyyyMMdd"));
                 int st = int.Parse(account.DateOfAccountOpening.ToString("yyyyMMdd"));
                 double yr = (now - st) / 10000;
                 double si = (balance * account.InterestRate * yr) / 100;*/
                account.CurrentBalance = balance;
                account.LastModifiedDateTime = DateTime.Now;
                BalanceUpdated = true;
            }
            catch (Exception)
            {
                throw;
            }

            return BalanceUpdated;
        }

        /// <summary>
        /// Updates the branch of an account
        /// </summary>
        /// <param name="accountNumber">Contains the account number of the account.</param>
        /// <returns>Determines whether the branch is updated or not.</returns>
        public override bool UpdateBranchDAL(string accountNumber, string branch)
        {
            bool AccountBranchUpdated = false;

            try
            {
                //Account account = new Account();
                RegularAccount account;
                account = regularAccountList.Find(x => x.AccountNo == accountNumber);
                account.Branch = branch;
                account.LastModifiedDateTime = DateTime.Now;
                AccountBranchUpdated = true;
            }
            catch (Exception)
            {
                throw;
            }
            return AccountBranchUpdated;
        }

        /// <summary>
        /// Updates the account type from savings to current or vice-versa
        /// </summary>
        /// <param name="accountNumber">Contains the account number of the account.</param>
        /// <param name="accountType">Contains the new account type of the account.</param>
        /// <returns>Determines whether the account type is updated or not.</returns>
        public override bool UpdateAccountTypeDAL(string accountNumber, string accountType)
        {
            bool AccountTypeUpdated = false;

            try
            {
                if ((accountType == "Savings") || (accountType == "Current"))
                {
                    RegularAccount account;
                    account = regularAccountList.Find(x => x.AccountNo == accountNumber);
                    account.AccountType = accountType;
                    account.LastModifiedDateTime = DateTime.Now;
                    AccountTypeUpdated = true;
                }
            }
            catch (Exception)
            {
                throw;
            }
            return AccountTypeUpdated;
        }

        /// <summary>
        /// Deletes an existing account
        /// </summary>
        /// <param name="deleteAccountNo">Contains the account number of the account to be deleted.</param>
        /// <returns>Determines whether the account is deleted or not.</returns>
        public override bool DeleteAccountDAL(string deleteAccountNo)
        {
            bool AccountDeleted = false;

            try
            {
                RegularAccount deleteAccount = null;
                RegularAccount account;
                account = regularAccountList.Find(x => x.AccountNo == deleteAccountNo);
                account.Status = "Closed";
                deleteAccount = account;
                account.LastModifiedDateTime = DateTime.Now;

                if (deleteAccountNo != null)
                {
                    //AccountList.Remove(deleteAccount);
                    AccountDeleted = true;
                }
            }
            catch (Exception)
            {
                throw;
            }
            return AccountDeleted;

        }


        /// <summary>
        /// Clears unmanaged resources such as db connections or file streams.
        /// </summary>

        public void Dispose()
        {
            throw new NotImplementedException();
        }
    }
}
