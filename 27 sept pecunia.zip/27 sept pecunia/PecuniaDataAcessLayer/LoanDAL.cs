﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pecunia.Entities;
using Pecunia.Helpers;
using Pecunia.Contracts.DALContracts;

namespace Pecunia.DataAcessLayer
{
    public class CarLoanDAL : CarLoanDALBase, IDisposable
    {
        /// <summary>
        /// Adds new Loan to Loans collection.
        /// </summary>
        /// <param name="NewLoan">Contains the details of new loan to be added.</param>
        /// <returns>Determinates whether the new Loan is added.</returns>
        public override bool AddLoanDAL(CarLoan NewLoan)
        {
            bool LoanAdded = false;
            try
            {
                NewLoan.LoanType = "Car";
                NewLoan.LoanStatus = "Pending";
                //NewLoan.LoanID = Guid.NewGuid();
                NewLoan.LoanApplyDate = DateTime.Now;
                CarLoanList.Add(NewLoan);
                LoanAdded = true;
            }
            catch (Exception)
            {
                throw;
            }
            return LoanAdded;
        }

        /// <summary>
        /// Will Return the list of all Loan Applied
        /// </summary>
        /// <returns>Returns List containing Loan Information</returns>
        public override List<CarLoan> GetAllCarLoanDAL()
        {
            return CarLoanList;
        }

        /// <summary>
        /// Will Return Information of loan based on loan ID
        /// </summary>
        /// <param name="loanID">Will take loan ID from user</param>
        /// <returns>Loan Related Information</returns>
        public override CarLoan GetCarLoanByLoanIDDAL(Guid loanID)
        {
            CarLoan LoanByID = null;
            try
            {
                LoanByID = CarLoanList.Find(x => x.LoanID == loanID);
            }
            catch (Exception)
            {
                throw;
            }
            return LoanByID;
        }

        /// <summary>
        /// Will return list of loan based on type like home car personal education
        /// </summary>
        /// <param name="LoanType">can be Car Home Education or Personal</param>
        /// <returns>Returns List</returns>
        public override List<CarLoan> GetCarLoanByTypeDAL(string LoanType)
        {
            List<CarLoan> loanlist = null;
            try
            {

                loanlist = CarLoanList.FindAll(x => x.LoanType == LoanType);
            }
            catch (Exception)
            {
                throw;
            }
            return loanlist;
        }

        /// <summary>
        /// Will Return list of loan based on Approved Rejected Pending 
        /// </summary>
        /// <param name="LoanStatus">Can be Approved Rejected Pending</param>
        /// <returns>Return List</returns>
        public override List<CarLoan> GetCarLoanByLoanStatusDAL(string LoanStatus)
        {
            List<CarLoan> loanlist = null;
            try
            {

                loanlist = CarLoanList.FindAll(x => x.LoanStatus == LoanStatus);
            }
            catch (Exception)
            {
                throw;
            }
            return loanlist;
        }
        /// <summary>
        /// Method to Update Existing Loan by replacing entire loan by updated loan
        /// </summary>
        /// <param name="updatedloan"> Will Contain Information of updated Loan</param>
        /// <returns>Wether bool is updated or not </returns>
        public override bool UpdateCarLoanDAL(CarLoan updatedloan)
        {
            bool update = false;
            try
            {
                //Find CarLoan based on carLoanID
                CarLoan matchingloan = GetCarLoanByLoanIDDAL(updatedloan.LoanID);

                if (updatedloan != null)
                {
                    //Update CarLoan details
                    ReflectionHelpers.CopyProperties(updatedloan, matchingloan, new List<string>() { "LoanType", "AmtOfLoan", "Tenure", "YearlyIncome", "YearsOfService", "LoanStatus", "License" });
                    update = true;
                }
            }
            catch (Exception)
            {
                throw;
            }
            return update;
        }
        public override bool DeleteCarLoanDAL(Guid deleteLoanID)
        {
            bool LoanDeleted = false;
            CarLoan LoanByID = GetCarLoanByLoanIDDAL(deleteLoanID);
            try
            {

                CarLoanList.Remove(LoanByID);
                LoanDeleted = true;
            }
            catch (Exception)
            {
                throw;
            }
            return LoanDeleted;
        }

        public void Dispose()
        {

        }
    }

    public class HomeLoanDAL : HomeLoanDALBase, IDisposable
    {
        /// <summary>
        /// Adds new Loan to Loans collection.
        /// </summary>
        /// <param name="NewLoan">Contains the details of new loan to be added.</param>
        /// <returns>Determinates whether the new Loan is added.</returns>
        public override bool AddLoanDAL(HomeLoan NewLoan)
        {
            bool LoanAdded = false;
            try
            {
                NewLoan.LoanType = "Home";
                NewLoan.LoanStatus = "Pending";
                NewLoan.LoanID = Guid.NewGuid();
                NewLoan.LoanApplyDate = DateTime.Now;
                HomeLoanList.Add(NewLoan);
                LoanAdded = true;
            }
            catch (Exception)
            {
                throw;
            }
            return LoanAdded;
        }

        /// <summary>
        /// Will Return the list of all Loan Applied
        /// </summary>
        /// <returns>Returns List containing Loan Information</returns>
        public override List<HomeLoan> GetAllHomeLoanDAL()
        {
            return HomeLoanList;
        }

        /// <summary>
        /// Will Return Information of loan based on loan ID
        /// </summary>
        /// <param name="loanID">Will take loan ID from user</param>
        /// <returns>Loan Related Information</returns>
        public override HomeLoan GetHomeLoanByLoanIDDAL(Guid loanID)
        {
            HomeLoan LoanByID = null;
            try
            {
                LoanByID = HomeLoanList.Find(x => x.LoanID == loanID);
            }
            catch (Exception)
            {
                throw;
            }
            return LoanByID;
        }

        /// <summary>
        /// Will return list of loan based on type like home  
        /// </summary>
        /// <param name="LoanType">can be Car Home Education or Personal</param>
        /// <returns>Returns List</returns>
        public override List<HomeLoan> GetHomeLoanByTypeDAL(string LoanType)
        {
            List<HomeLoan> loanlist = null;
            try
            {

                loanlist = HomeLoanList.FindAll(x => x.LoanType == LoanType);
            }
            catch (Exception)
            {
                throw;
            }
            return loanlist;
        }

        /// <summary>
        /// Will Return list of loan based on Approved Rejected Pending 
        /// </summary>
        /// <param name="LoanStatus">Can be Approved Rejected Pending</param>
        /// <returns>Return List</returns>
        public override List<HomeLoan> GetHomeLoanByLoanStatusDAL(string LoanStatus)
        {
            List<HomeLoan> loanlist = null;
            try
            {

                loanlist = HomeLoanList.FindAll(x => x.LoanStatus == LoanStatus);
            }
            catch (Exception)
            {
                throw;
            }
            return loanlist;
        }
        /// <summary>
        /// Method to Update Existing Loan by replacing entire loan by updated loan
        /// </summary>
        /// <param name="updatedloan"> Will Contain Information of updated Loan</param>
        /// <returns>Wether bool is updated or not </returns>
        public override bool UpdateHomeLoanDAL(HomeLoan updatedloan)
        {
            bool update = false;
            try
            {
                //Find Loan based on LoanID
                HomeLoan matchingloan = GetHomeLoanByLoanIDDAL(updatedloan.LoanID);

                if (updatedloan != null)
                {
                    //Update loan details
                    ReflectionHelpers.CopyProperties(updatedloan, matchingloan, new List<string>() { "LoanType", "AmtOfLoan", "LoanStatus", "YearlyIncome", "YearsOfService", "Collateral", "LoanID" });
                    update = true;
                }
            }
            catch (Exception)
            {
                throw;
            }
            return update;
        }
        public override bool DeleteHomeLoanDAL(Guid deleteLoanID)
        {
            bool LoanDeleted = false;
            HomeLoan LoanByID = GetHomeLoanByLoanIDDAL(deleteLoanID);
            try
            {

                HomeLoanList.Remove(LoanByID);
                LoanDeleted = true;
            }
            catch (Exception)
            {
                throw;
            }
            return LoanDeleted;
        }

        public void Dispose()
        {

        }
    }

    public class PersonalLoanDAL : PersonalLoanDALBase, IDisposable
    {
        /// <summary>
        /// Adds new Loan to Loans collection.
        /// </summary>
        /// <param name="NewLoan">Contains the details of new loan to be added.</param>
        /// <returns>Determinates whether the new Loan is added.</returns>
        public override bool AddLoanDAL(PersonalLoan NewLoan)
        {
            bool LoanAdded = false;
            try
            {
                NewLoan.LoanType = "Personal";
                NewLoan.LoanStatus = "Pending";
                NewLoan.LoanID = Guid.NewGuid();
                NewLoan.LoanApplyDate = DateTime.Now;
                PersonalLoanList.Add(NewLoan);
                LoanAdded = true;
            }
            catch (Exception)
            {
                throw;
            }
            return LoanAdded;
        }

        /// <summary>
        /// Will Return the list of all Loan Applied
        /// </summary>
        /// <returns>Returns List containing Loan Information</returns>
        public override List<PersonalLoan> GetAllPersonalLoanDAL()
        {
            return PersonalLoanList;
        }

        /// <summary>
        /// Will Return Information of loan based on loan ID
        /// </summary>
        /// <param name="loanID">Will take loan ID from user</param>
        /// <returns>Loan Related Information</returns>
        public override PersonalLoan GetPersonalLoanByLoanIDDAL(Guid loanID)
        {
            PersonalLoan LoanByID = null;
            try
            {
                LoanByID = PersonalLoanList.Find(x => x.LoanID == loanID);
            }
            catch (Exception)
            {
                throw;
            }
            return LoanByID;
        }

        /// <summary>
        /// Will return list of loan based on type like home car personal education
        /// </summary>
        /// <param name="LoanType">can be Car Home Education or Personal</param>
        /// <returns>Returns List</returns>
        public override List<PersonalLoan> GetPersonalLoanByTypeDAL(string LoanType)
        {
            List<PersonalLoan> loanlist = null;
            try
            {

                loanlist = PersonalLoanList.FindAll(x => x.LoanType == LoanType);
            }
            catch (Exception)
            {
                throw;
            }
            return loanlist;
        }

        /// <summary>
        /// Will Return list of loan based on Approved Rejected Pending 
        /// </summary>
        /// <param name="LoanStatus">Can be Approved Rejected Pending</param>
        /// <returns>Return List</returns>
        public override List<PersonalLoan> GetPersonalLoanByLoanStatusDAL(string LoanStatus)
        {
            List<PersonalLoan> loanlist = null;
            try
            {

                loanlist = PersonalLoanList.FindAll(x => x.LoanStatus == LoanStatus);
            }
            catch (Exception)
            {
                throw;
            }
            return loanlist;
        }
        /// <summary>
        /// Method to Update Existing Loan by replacing entire loan by updated loan
        /// </summary>
        /// <param name="updatedloan"> Will Contain Information of updated Loan</param>
        /// <returns>Wether bool is updated or not </returns>
        public override bool UpdatePersonalLoanDAL(PersonalLoan updatedloan)
        {
            bool update = false;
            try
            {
                //Find Loan based on LoanID
                PersonalLoan matchingloan = GetPersonalLoanByLoanIDDAL(updatedloan.LoanID);

                if (updatedloan != null)
                {
                    //Update Loan details
                    ReflectionHelpers.CopyProperties(updatedloan, matchingloan, new List<string>() { "LoanType", "AmtOfLoan", "LoanStatus", "YearlyIncome", "YearsOfService", "Collateral", "CollegeName", "AdmissionId", "LoanId" });
                    update = true;
                }
            }
            catch (Exception)
            {
                throw;
            }
            return update;
        }
        public override bool DeletePersonalLoanDAL(Guid deleteLoanID)
        {
            bool LoanDeleted = false;
            PersonalLoan LoanByID = GetPersonalLoanByLoanIDDAL(deleteLoanID);
            try
            {

                PersonalLoanList.Remove(LoanByID);
                LoanDeleted = true;
            }
            catch (Exception)
            {
                throw;
            }
            return LoanDeleted;
        }

        public void Dispose()
        {

        }
    }

    public class EducationLoanDAL : EducationLoanDALBase, IDisposable
    {
        /// <summary>
        /// Adds new Loan to Loans collection.
        /// </summary>
        /// <param name="NewLoan">Contains the details of new loan to be added.</param>
        /// <returns>Determinates whether the new Loan is added.</returns>
        public override bool AddLoanDAL(EducationLoan NewLoan)
        {
            bool LoanAdded = false;
            try
            {
                NewLoan.LoanType = "Education";
                NewLoan.LoanStatus = "Pending";
                NewLoan.LoanID = Guid.NewGuid();
                NewLoan.LoanApplyDate = DateTime.Now;
                EducationLoanList.Add(NewLoan);
                LoanAdded = true;
            }
            catch (Exception)
            {
                throw;
            }
            return LoanAdded;
        }

        /// <summary>
        /// Will Return the list of all Loan Applied
        /// </summary>
        /// <returns>Returns List containing Loan Information</returns>
        public override List<EducationLoan> GetAllEducationLoanDAL()
        {
            return EducationLoanList;
        }

        /// <summary>
        /// Will Return Information of loan based on loan ID
        /// </summary>
        /// <param name="loanID">Will take loan ID from user</param>
        /// <returns>Loan Related Information</returns>
        public override EducationLoan GetEducationLoanByLoanIDDAL(Guid loanID)
        {
            EducationLoan LoanByID = null;
            try
            {
                LoanByID = EducationLoanList.Find(x => x.LoanID == loanID);
            }
            catch (Exception)
            {
                throw;
            }
            return LoanByID;
        }

        /// <summary>
        /// Will return list of loan based on type like home car personal education
        /// </summary>
        /// <param name="LoanType">can be Car Home Education or Personal</param>
        /// <returns>Returns List</returns>
        public override List<EducationLoan> GetEducationLoanByTypeDAL(string LoanType)
        {
            List<EducationLoan> loanlist = null;
            try
            {

                loanlist = EducationLoanList.FindAll(x => x.LoanType == LoanType);
            }
            catch (Exception)
            {
                throw;
            }
            return loanlist;
        }

        /// <summary>
        /// Will Return list of loan based on Approved Rejected Pending 
        /// </summary>
        /// <param name="LoanStatus">Can be Approved Rejected Pending</param>
        /// <returns>Return List</returns>
        public override List<EducationLoan> GetEducationLoanByLoanStatusDAL(string LoanStatus)
        {
            List<EducationLoan> loanlist = null;
            try
            {

                loanlist = EducationLoanList.FindAll(x => x.LoanStatus == LoanStatus);
            }
            catch (Exception)
            {
                throw;
            }
            return loanlist;
        }
        /// <summary>
        /// Method to Update Existing Loan by replacing entire loan by updated loan
        /// </summary>
        /// <param name="updatedloan"> Will Contain Information of updated Loan</param>
        /// <returns>Wether bool is updated or not </returns>
        public override bool UpdateEducationLoanDAL(EducationLoan updatedloan)
        {
            bool update = false;
            try
            {
                //Find Loan based on LoanID
                EducationLoan matchingloan = GetEducationLoanByLoanIDDAL(updatedloan.LoanID);

                if (updatedloan != null)
                {
                    //Update Loan details
                    ReflectionHelpers.CopyProperties(updatedloan, matchingloan, new List<string>() { "LoanType", "AmtOfLoan", "LoanStatus", "YearlyIncome", "YearsOfService", "Collateral", "LoanID" });
                    update = true;
                }
            }
            catch (Exception)
            {
                throw;
            }
            return update;
        }
        public override bool DeleteEducationLoanDAL(Guid deleteLoanID)
        {
            bool LoanDeleted = false;
            EducationLoan LoanByID = GetEducationLoanByLoanIDDAL(deleteLoanID);
            try
            {

                EducationLoanList.Remove(LoanByID);
                LoanDeleted = true;
            }
            catch (Exception)
            {
                throw;
            }
            return LoanDeleted;
        }

        public void Dispose()
        {

        }
    }

}
