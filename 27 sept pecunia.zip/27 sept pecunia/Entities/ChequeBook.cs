﻿using Pecunia.Helpers.ValidationAttribute;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pecunia.Entities
{/// <summary>
 /// Interface for ChequeBook Entity
 /// </summary>
    public interface IChequeBook
    {
        string ChequeBookId { get; set; }
        Guid AccountId { get; set; }
        string AccountNo { get; set; }
        double SeriesStart { get; set; }
        DateTime ChequeBookRequestDate { get; set; }
        DateTime LastModifiedDate { get; set; }
        int NumberOfLeaves { get; set; }
        string ChequeBookStatus { get; set; }

    }

    /// <summary>
    /// Represents DebitCard
    /// </summary>
    public class ChequeBook : IChequeBook
    {/* Auto-Implemented Properties */

        [Required("ChequeBook ID can't be blank.")]
        public string ChequeBookId { get; set; }
        [Required("Account ID can't be blank.")]
        public Guid AccountId { get; set; }
       
        public string AccountNo { get; set; }
        [Required("Series starting number should not be null.")]
        [RegExp(@"^([0-9]{8})$", "Length of the series should be 8")]
        public double SeriesStart { get; set; }
        public DateTime ChequeBookRequestDate { get; set; }
        public DateTime LastModifiedDate { get; set; }
        public int NumberOfLeaves { get; set; }
        public string ChequeBookStatus { get; set; }
        public ChequeBook()
        {
            ChequeBookId = null;
            AccountId = default(Guid);
            AccountNo = null;
            SeriesStart = default(long);
            NumberOfLeaves = default(int);
            ChequeBookStatus = null;

        }

    }
}
